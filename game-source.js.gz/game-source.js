(() => {
  "use strict";

  const CONFIG = Object.freeze({
    worldWidth: 3600,
    worldHeight: 2400,
    cols: 90,
    rows: 60,
    matchDurationMs: 5 * 60 * 1000,
    players: 9,
    playersPerTeam: 3,
    playerRadius: 18,
    playerSpeed: 245,
    dashSpeed: 620,
    dashDurationMs: 170,
    dashCooldownMs: 1800,
    projectileSpeed: 720,
    projectileLifeMs: 1150,
    shotCooldownMs: 650,
    respawnShieldMs: 1400,
    questionDurationMs: 20000,
    claimRadiusCells: 1,
    initialClaimRadiusCells: 4,
    botAccuracy: 0.72,
    botAnswerMinMs: 1300,
    botAnswerMaxMs: 4300
  });

  const TEAM_DEFS = Object.freeze([
    { id: 0, name: "Cyan Circuit", color: "#22b8d6", pale: "#bfeef7", dark: "#087b98" },
    { id: 1, name: "Magenta Pulse", color: "#ed4f86", pale: "#ffd1df", dark: "#9d204b" },
    { id: 2, name: "Amber Forge", color: "#f2b23b", pale: "#ffe8b5", dark: "#9b6500" }
  ]);

  const BOT_NAMES = [
    "Axiom", "Vector", "Sine", "Cosine", "Tangent", "Vertex", "Arc", "Ratio"
  ];

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d", { alpha: false });
  const minimapCanvas = document.getElementById("minimapCanvas");
  const mctx = minimapCanvas.getContext("2d", { alpha: false });
  const questionCanvas = document.getElementById("questionCanvas");
  const qctx = questionCanvas.getContext("2d", { alpha: false });

  const ui = {
    lobbyOverlay: document.getElementById("lobbyOverlay"),
    questionOverlay: document.getElementById("questionOverlay"),
    endOverlay: document.getElementById("endOverlay"),
    startButton: document.getElementById("startButton"),
    playAgainButton: document.getElementById("playAgainButton"),
    soundButton: document.getElementById("soundButton"),
    playerNameInput: document.getElementById("playerNameInput"),
    teamSelect: document.getElementById("teamSelect"),
    phaseLabel: document.getElementById("phaseLabel"),
    clockLabel: document.getElementById("clockLabel"),
    matchClock: document.querySelector(".match-clock"),
    eventBanner: document.getElementById("eventBanner"),
    playerNameLabel: document.getElementById("playerNameLabel"),
    playerStateLabel: document.getElementById("playerStateLabel"),
    playerTeamDot: document.getElementById("playerTeamDot"),
    playerTerritoryLabel: document.getElementById("playerTerritoryLabel"),
    playerKillsLabel: document.getElementById("playerKillsLabel"),
    playerDeathsLabel: document.getElementById("playerDeathsLabel"),
    playerAccuracyLabel: document.getElementById("playerAccuracyLabel"),
    shotCooldown: document.getElementById("shotCooldown"),
    dashCooldown: document.getElementById("dashCooldown"),
    questionTitle: document.getElementById("questionTitle"),
    questionTimer: document.getElementById("questionTimer"),
    questionPrompt: document.getElementById("questionPrompt"),
    questionOptions: document.getElementById("questionOptions"),
    questionFeedback: document.getElementById("questionFeedback"),
    endTitle: document.getElementById("endTitle"),
    winnerSummary: document.getElementById("winnerSummary"),
    finalRanking: document.getElementById("finalRanking"),
    reportTableBody: document.getElementById("reportTableBody"),
    downloadCsvButton: document.getElementById("downloadCsvButton"),
    downloadJsonButton: document.getElementById("downloadJsonButton"),
    teamTerritory: [0, 1, 2].map((i) => document.getElementById(`team${i}Territory`)),
    teamKills: [0, 1, 2].map((i) => document.getElementById(`team${i}Kills`))
  };

  const cellWidth = CONFIG.worldWidth / CONFIG.cols;
  const cellHeight = CONFIG.worldHeight / CONFIG.rows;

  let gameState = "lobby";
  let matchStartedAt = 0;
  let matchEndedAt = 0;
  let lastFrameAt = performance.now();
  let humanPlayerId = null;
  let players = [];
  let projectiles = [];
  let particles = [];
  let territory = new Int8Array(CONFIG.cols * CONFIG.rows);
  let territoryCounts = [0, 0, 0];
  let teamKills = [0, 0, 0];
  let currentReport = null;
  let bannerTimer = null;
  let soundEnabled = true;
  let audioContext = null;
  let humanQuestion = null;
  let humanQuestionLocked = false;
  let selectedHumanTeam = 0;
  let playerName = "Student 1";
  let camera = { x: CONFIG.worldWidth / 2, y: CONFIG.worldHeight / 2, zoom: 0.55 };
  let mouse = { x: 0, y: 0, worldX: CONFIG.worldWidth / 2, worldY: CONFIG.worldHeight / 2 };
  let input = { up: false, down: false, left: false, right: false, fire: false, dash: false };
  let canvasCssWidth = 1;
  let canvasCssHeight = 1;
  let deviceScale = 1;

  territory.fill(-1);

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function randomRange(min, max) {
    return min + Math.random() * (max - min);
  }

  function distanceSq(ax, ay, bx, by) {
    const dx = ax - bx;
    const dy = ay - by;
    return dx * dx + dy * dy;
  }

  function normalize(dx, dy) {
    const length = Math.hypot(dx, dy);
    if (length < 0.0001) return { x: 0, y: 0 };
    return { x: dx / length, y: dy / length };
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function cleanName(value) {
    const cleaned = String(value || "")
      .replace(/[^a-zA-Z0-9 _-]/g, "")
      .trim()
      .slice(0, 18);
    return cleaned || "Student 1";
  }

  function formatTime(ms) {
    const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  function formatPercent(value) {
    return `${(value * 100).toFixed(value >= 0.1 ? 1 : 2)}%`;
  }

  function accuracyOf(player) {
    const attempts = player.questionStats.attempts;
    return attempts > 0 ? player.questionStats.correct / attempts : null;
  }

  function cellIndex(col, row) {
    return row * CONFIG.cols + col;
  }

  function worldToCell(x, y) {
    return {
      col: clamp(Math.floor(x / cellWidth), 0, CONFIG.cols - 1),
      row: clamp(Math.floor(y / cellHeight), 0, CONFIG.rows - 1)
    };
  }

  function resizeCanvas() {
    canvasCssWidth = Math.max(1, window.innerWidth);
    canvasCssHeight = Math.max(1, window.innerHeight);
    deviceScale = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(canvasCssWidth * deviceScale);
    canvas.height = Math.round(canvasCssHeight * deviceScale);
    canvas.style.width = `${canvasCssWidth}px`;
    canvas.style.height = `${canvasCssHeight}px`;
    ctx.setTransform(deviceScale, 0, 0, deviceScale, 0, 0);
  }

  function worldToScreen(x, y) {
    return {
      x: (x - camera.x) * camera.zoom + canvasCssWidth / 2,
      y: (y - camera.y) * camera.zoom + canvasCssHeight / 2
    };
  }

  function screenToWorld(x, y) {
    return {
      x: (x - canvasCssWidth / 2) / camera.zoom + camera.x,
      y: (y - canvasCssHeight / 2) / camera.zoom + camera.y
    };
  }

  function ensureAudio() {
    if (!soundEnabled) return null;
    if (!audioContext) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return null;
      audioContext = new AudioContextClass();
    }
    if (audioContext.state === "suspended") audioContext.resume().catch(() => {});
    return audioContext;
  }

  function playTone(frequency, duration = 0.08, type = "sine", volume = 0.035) {
    const ac = ensureAudio();
    if (!ac) return;
    const oscillator = ac.createOscillator();
    const gain = ac.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, ac.currentTime);
    gain.gain.setValueAtTime(volume, ac.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + duration);
    oscillator.connect(gain).connect(ac.destination);
    oscillator.start();
    oscillator.stop(ac.currentTime + duration);
  }

  function showBanner(message, duration = 1800) {
    ui.eventBanner.textContent = message;
    ui.eventBanner.classList.add("visible");
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(() => ui.eventBanner.classList.remove("visible"), duration);
  }

  function generateSpawnPoints() {
    const points = [];
    let attempts = 0;
    while (points.length < CONFIG.players && attempts < 5000) {
      attempts += 1;
      const candidate = {
        x: randomRange(320, CONFIG.worldWidth - 320),
        y: randomRange(260, CONFIG.worldHeight - 260)
      };
      if (points.every((point) => distanceSq(point.x, point.y, candidate.x, candidate.y) > 460 * 460)) {
        points.push(candidate);
      }
    }
    while (points.length < CONFIG.players) {
      const angle = (points.length / CONFIG.players) * Math.PI * 2;
      points.push({
        x: CONFIG.worldWidth / 2 + Math.cos(angle) * 1050,
        y: CONFIG.worldHeight / 2 + Math.sin(angle) * 690
      });
    }
    return points.sort(() => Math.random() - 0.5);
  }

  function createPlayer(id, team, name, isHuman, spawn) {
    return {
      id,
      slot: Number(id.replace("p", "")),
      team,
      name,
      isHuman,
      x: spawn.x,
      y: spawn.y,
      prevX: spawn.x,
      prevY: spawn.y,
      vx: 0,
      vy: 0,
      angle: randomRange(0, Math.PI * 2),
      alive: true,
      shieldUntil: performance.now() + 1800,
      shotReadyAt: performance.now(),
      dashReadyAt: performance.now(),
      dashUntil: 0,
      kills: 0,
      deaths: 0,
      territoryClaimed: 0,
      questionSequence: 0,
      question: null,
      questionStats: {
        attempts: 0,
        correct: 0,
        wrong: 0,
        timeouts: 0,
        totalResponseMs: 0,
        answers: []
      },
      bot: {
        targetX: spawn.x,
        targetY: spawn.y,
        nextDecisionAt: 0,
        nextFireAt: 0,
        preferredOrbit: Math.random() < 0.5 ? -1 : 1
      }
    };
  }

  function startMatch() {
    playerName = cleanName(ui.playerNameInput.value);
    selectedHumanTeam = clamp(Number(ui.teamSelect.value) || 0, 0, 2);
    ensureAudio();

    gameState = "running";
    matchStartedAt = performance.now();
    matchEndedAt = 0;
    currentReport = null;
    humanQuestion = null;
    humanQuestionLocked = false;
    projectiles = [];
    particles = [];
    players = [];
    territory = new Int8Array(CONFIG.cols * CONFIG.rows);
    territory.fill(-1);
    territoryCounts = [0, 0, 0];
    teamKills = [0, 0, 0];

    const spawns = generateSpawnPoints();
    let playerIndex = 0;
    let botNameIndex = 0;
    for (let team = 0; team < 3; team += 1) {
      for (let member = 0; member < CONFIG.playersPerTeam; member += 1) {
        const isHuman = team === selectedHumanTeam && member === 0;
        const id = `p${playerIndex}`;
        const name = isHuman ? playerName : `${TEAM_DEFS[team].name.split(" ")[0]} ${BOT_NAMES[botNameIndex++]}`;
        const player = createPlayer(id, team, name, isHuman, spawns[playerIndex]);
        players.push(player);
        claimCircle(team, player.x, player.y, CONFIG.initialClaimRadiusCells, player);
        if (isHuman) humanPlayerId = id;
        playerIndex += 1;
      }
    }

    const human = getHumanPlayer();
    camera.x = human.x;
    camera.y = human.y;
    camera.zoom = clamp(Math.min(canvasCssWidth / 1600, canvasCssHeight / 1050), 0.48, 0.78);

    ui.lobbyOverlay.classList.remove("visible");
    ui.endOverlay.classList.remove("visible");
    ui.questionOverlay.classList.remove("visible");
    ui.phaseLabel.textContent = "MATCH";
    ui.playerNameLabel.textContent = human.name;
    ui.playerTeamDot.style.background = TEAM_DEFS[human.team].color;
    ui.playerStateLabel.textContent = TEAM_DEFS[human.team].name;
    showBanner("MATCH START · CLAIM THE LARGEST TERRITORY", 2300);
    playTone(523, 0.12, "triangle", 0.05);
  }

  function getHumanPlayer() {
    return players.find((player) => player.id === humanPlayerId) || players[0] || null;
  }

  function claimCircle(team, x, y, radiusCells, ownerPlayer = null) {
    const center = worldToCell(x, y);
    let changed = 0;
    for (let row = center.row - radiusCells; row <= center.row + radiusCells; row += 1) {
      if (row < 0 || row >= CONFIG.rows) continue;
      for (let col = center.col - radiusCells; col <= center.col + radiusCells; col += 1) {
        if (col < 0 || col >= CONFIG.cols) continue;
        const dx = col - center.col;
        const dy = row - center.row;
        if (dx * dx + dy * dy > radiusCells * radiusCells + 0.5) continue;
        const index = cellIndex(col, row);
        const previous = territory[index];
        if (previous === team) continue;
        if (previous >= 0) territoryCounts[previous] -= 1;
        territory[index] = team;
        territoryCounts[team] += 1;
        changed += 1;
      }
    }
    if (ownerPlayer) {
      ownerPlayer.territoryClaimed += changed;
    }
    return changed;
  }

  function chooseBotTarget(bot, now) {
    const enemies = players.filter((candidate) => candidate.alive && candidate.team !== bot.team);
    const nearestEnemy = enemies
      .map((candidate) => ({ candidate, d2: distanceSq(bot.x, bot.y, candidate.x, candidate.y) }))
      .sort((a, b) => a.d2 - b.d2)[0];

    if (nearestEnemy && nearestEnemy.d2 < 760 * 760 && Math.random() < 0.58) {
      const enemy = nearestEnemy.candidate;
      const angle = Math.atan2(enemy.y - bot.y, enemy.x - bot.x) + bot.bot.preferredOrbit * randomRange(0.25, 0.65);
      bot.bot.targetX = clamp(enemy.x + Math.cos(angle) * randomRange(150, 330), 90, CONFIG.worldWidth - 90);
      bot.bot.targetY = clamp(enemy.y + Math.sin(angle) * randomRange(150, 330), 90, CONFIG.worldHeight - 90);
    } else {
      const bestCells = [];
      for (let i = 0; i < 18; i += 1) {
        const x = randomRange(100, CONFIG.worldWidth - 100);
        const y = randomRange(100, CONFIG.worldHeight - 100);
        const { col, row } = worldToCell(x, y);
        const owner = territory[cellIndex(col, row)];
        bestCells.push({ x, y, score: owner === bot.team ? 0 : owner < 0 ? 2 : 3 });
      }
      bestCells.sort((a, b) => b.score - a.score || Math.random() - 0.5);
      bot.bot.targetX = bestCells[0].x;
      bot.bot.targetY = bestCells[0].y;
    }
    bot.bot.nextDecisionAt = now + randomRange(700, 1500);
  }

  function updateBots(now) {
    for (const bot of players) {
      if (bot.isHuman || !bot.alive) continue;
      if (now >= bot.bot.nextDecisionAt || distanceSq(bot.x, bot.y, bot.bot.targetX, bot.bot.targetY) < 95 * 95) {
        chooseBotTarget(bot, now);
      }

      const direction = normalize(bot.bot.targetX - bot.x, bot.bot.targetY - bot.y);
      bot.vx = direction.x;
      bot.vy = direction.y;

      const enemy = players
        .filter((candidate) => candidate.alive && candidate.team !== bot.team)
        .map((candidate) => ({ candidate, d2: distanceSq(bot.x, bot.y, candidate.x, candidate.y) }))
        .sort((a, b) => a.d2 - b.d2)[0];

      if (enemy && enemy.d2 < 820 * 820) {
        bot.angle = Math.atan2(enemy.candidate.y - bot.y, enemy.candidate.x - bot.x);
        if (now >= bot.shotReadyAt && now >= bot.bot.nextFireAt && Math.random() < 0.13) {
          fireProjectile(bot, now);
          bot.bot.nextFireAt = now + randomRange(420, 920);
        }
        if (enemy.d2 < 250 * 250 && now >= bot.dashReadyAt && Math.random() < 0.025) {
          bot.dashUntil = now + CONFIG.dashDurationMs;
          bot.dashReadyAt = now + CONFIG.dashCooldownMs;
        }
      } else {
        bot.angle = Math.atan2(direction.y, direction.x);
      }
    }
  }

  function updateHumanInput(human, now) {
    if (!human || !human.alive || humanQuestion) return;
    let dx = 0;
    let dy = 0;
    if (input.left) dx -= 1;
    if (input.right) dx += 1;
    if (input.up) dy -= 1;
    if (input.down) dy += 1;
    const movement = normalize(dx, dy);
    human.vx = movement.x;
    human.vy = movement.y;
    human.angle = Math.atan2(mouse.worldY - human.y, mouse.worldX - human.x);

    if (input.dash && now >= human.dashReadyAt) {
      human.dashUntil = now + CONFIG.dashDurationMs;
      human.dashReadyAt = now + CONFIG.dashCooldownMs;
      playTone(180, 0.06, "sawtooth", 0.025);
    }
    input.dash = false;

    if (input.fire && now >= human.shotReadyAt) {
      fireProjectile(human, now);
      input.fire = false;
    }
  }

  function movePlayers(dt, now) {
    for (const player of players) {
      if (!player.alive) continue;
      player.prevX = player.x;
      player.prevY = player.y;
      const speed = now < player.dashUntil ? CONFIG.dashSpeed : CONFIG.playerSpeed;
      player.x = clamp(player.x + player.vx * speed * dt, CONFIG.playerRadius, CONFIG.worldWidth - CONFIG.playerRadius);
      player.y = clamp(player.y + player.vy * speed * dt, CONFIG.playerRadius, CONFIG.worldHeight - CONFIG.playerRadius);
      claimCircle(player.team, player.x, player.y, CONFIG.claimRadiusCells, player);
    }
  }

  function fireProjectile(player, now) {
    player.shotReadyAt = now + CONFIG.shotCooldownMs;
    const spread = player.isHuman ? 0 : randomRange(-0.06, 0.06);
    const angle = player.angle + spread;
    projectiles.push({
      id: `${player.id}-${now}-${Math.random()}`,
      ownerId: player.id,
      team: player.team,
      x: player.x + Math.cos(angle) * 28,
      y: player.y + Math.sin(angle) * 28,
      vx: Math.cos(angle) * CONFIG.projectileSpeed,
      vy: Math.sin(angle) * CONFIG.projectileSpeed,
      bornAt: now,
      expiresAt: now + CONFIG.projectileLifeMs,
      radius: 6
    });
    playTone(player.isHuman ? 420 : 330, 0.035, "square", 0.012);
  }

  function updateProjectiles(dt, now) {
    const survivors = [];
    for (const projectile of projectiles) {
      if (now >= projectile.expiresAt) continue;
      projectile.x += projectile.vx * dt;
      projectile.y += projectile.vy * dt;
      if (projectile.x < -30 || projectile.x > CONFIG.worldWidth + 30 || projectile.y < -30 || projectile.y > CONFIG.worldHeight + 30) continue;

      let hit = false;
      for (const player of players) {
        if (!player.alive || player.team === projectile.team || player.id === projectile.ownerId || now < player.shieldUntil) continue;
        const radius = CONFIG.playerRadius + projectile.radius;
        if (distanceSq(player.x, player.y, projectile.x, projectile.y) <= radius * radius) {
          eliminatePlayer(player, players.find((candidate) => candidate.id === projectile.ownerId) || null, now);
          hit = true;
          break;
        }
      }
      if (!hit) survivors.push(projectile);
    }
    projectiles = survivors;
  }

  function spawnExplosion(player) {
    const color = TEAM_DEFS[player.team].color;
    for (let i = 0; i < 34; i += 1) {
      const angle = randomRange(0, Math.PI * 2);
      const speed = randomRange(70, 360);
      particles.push({
        x: player.x,
        y: player.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        bornAt: performance.now(),
        life: randomRange(380, 850),
        size: randomRange(2, 7),
        color
      });
    }
  }

  function updateParticles(dt, now) {
    const survivors = [];
    for (const particle of particles) {
      const age = now - particle.bornAt;
      if (age >= particle.life) continue;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(0.94, dt * 60);
      particle.vy *= Math.pow(0.94, dt * 60);
      survivors.push(particle);
    }
    particles = survivors;
  }

  function eliminatePlayer(victim, attacker, now) {
    if (!victim.alive) return;
    victim.alive = false;
    victim.vx = 0;
    victim.vy = 0;
    victim.deaths += 1;
    victim.questionSequence += 1;
    if (attacker && attacker.team !== victim.team) {
      attacker.kills += 1;
      teamKills[attacker.team] += 1;
    }
    spawnExplosion(victim);
    createRespawnQuestion(victim, now);
    const attackerText = attacker ? attacker.name : "Arena pressure";
    showBanner(`${attackerText} eliminated ${victim.name}`);
    playTone(victim.isHuman ? 90 : 120, 0.18, "sawtooth", 0.045);
  }

  function createQuestionData(player, now) {
    const angles = [25, 30, 35, 40, 45, 50, 55, 60];
    const type = ["sin", "cos", "tan", "inverse"][Math.floor(Math.random() * 4)];
    let prompt;
    let answer;
    let diagram;

    if (type === "sin") {
      const angle = angles[Math.floor(Math.random() * angles.length)];
      const hypotenuse = Math.floor(randomRange(8, 19));
      answer = Math.round(Math.sin(angle * Math.PI / 180) * hypotenuse * 10) / 10;
      prompt = `The hypotenuse is ${hypotenuse} units and θ = ${angle}°. Find the opposite side.`;
      diagram = { type, angle, hypotenuse, opposite: "?", adjacent: null };
    } else if (type === "cos") {
      const angle = angles[Math.floor(Math.random() * angles.length)];
      const hypotenuse = Math.floor(randomRange(8, 19));
      answer = Math.round(Math.cos(angle * Math.PI / 180) * hypotenuse * 10) / 10;
      prompt = `The hypotenuse is ${hypotenuse} units and θ = ${angle}°. Find the adjacent side.`;
      diagram = { type, angle, hypotenuse, opposite: null, adjacent: "?" };
    } else if (type === "tan") {
      const angle = angles[Math.floor(Math.random() * angles.length)];
      const adjacent = Math.floor(randomRange(5, 15));
      answer = Math.round(Math.tan(angle * Math.PI / 180) * adjacent * 10) / 10;
      prompt = `The adjacent side is ${adjacent} units and θ = ${angle}°. Find the opposite side.`;
      diagram = { type, angle, hypotenuse: null, opposite: "?", adjacent };
    } else {
      const opposite = Math.floor(randomRange(4, 13));
      const adjacent = opposite + Math.floor(randomRange(3, 9));
      answer = Math.round(Math.atan(opposite / adjacent) * 180 / Math.PI);
      prompt = `The opposite side is ${opposite} and the adjacent side is ${adjacent}. Find θ to the nearest degree.`;
      diagram = { type, angle: "?", hypotenuse: null, opposite, adjacent };
    }

    const options = new Set([answer]);
    while (options.size < 4) {
      const scale = type === "inverse" ? 1 : 10;
      const delta = type === "inverse" ? Math.floor(randomRange(-16, 17)) : Math.round(randomRange(-45, 46)) / 10;
      let candidate = Math.round((answer + delta) * scale) / scale;
      candidate = Math.max(type === "inverse" ? 5 : 0.5, candidate);
      if (Math.abs(candidate - answer) >= (type === "inverse" ? 3 : 0.4)) options.add(candidate);
    }
    const shuffled = [...options].sort(() => Math.random() - 0.5);

    return {
      id: `${player.id}-q${player.questionSequence}-${Math.round(now)}-${Math.floor(Math.random() * 10000)}`,
      playerId: player.id,
      team: player.team,
      deathNumber: player.deaths,
      type,
      prompt,
      diagram,
      options: shuffled,
      correctIndex: shuffled.indexOf(answer),
      correctAnswer: answer,
      createdAt: now,
      expiresAt: now + CONFIG.questionDurationMs,
      botAnswerAt: now + randomRange(CONFIG.botAnswerMinMs, CONFIG.botAnswerMaxMs),
      resolved: false
    };
  }

  function createRespawnQuestion(player, now) {
    const question = createQuestionData(player, now);
    player.question = question;
    if (player.isHuman) {
      humanQuestion = question;
      humanQuestionLocked = false;
      renderHumanQuestion(question);
      ui.questionOverlay.classList.add("visible");
    }
  }

  function renderHumanQuestion(question) {
    ui.questionTitle.textContent = `Respawn ${question.deathNumber}: solve to return`;
    ui.questionPrompt.textContent = question.prompt;
    ui.questionFeedback.textContent = "";
    ui.questionFeedback.className = "question-feedback";
    ui.questionOptions.innerHTML = "";
    question.options.forEach((value, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "question-option";
      const suffix = question.type === "inverse" ? "°" : " units";
      button.textContent = `${String.fromCharCode(65 + index)}. ${value}${suffix}`;
      button.addEventListener("click", () => submitHumanAnswer(index));
      ui.questionOptions.appendChild(button);
    });
    drawQuestionDiagram(question);
  }

  function drawQuestionDiagram(question) {
    const width = questionCanvas.width;
    const height = questionCanvas.height;
    qctx.clearRect(0, 0, width, height);
    qctx.fillStyle = "#fbfcfe";
    qctx.fillRect(0, 0, width, height);

    const ax = 105;
    const ay = 205;
    const bx = 455;
    const by = 205;
    const cx = 455;
    const cy = 55;

    qctx.strokeStyle = "#111827";
    qctx.lineWidth = 5;
    qctx.lineJoin = "round";
    qctx.beginPath();
    qctx.moveTo(ax, ay);
    qctx.lineTo(bx, by);
    qctx.lineTo(cx, cy);
    qctx.closePath();
    qctx.stroke();

    qctx.lineWidth = 2;
    qctx.strokeRect(bx - 24, by - 24, 24, 24);
    qctx.beginPath();
    qctx.arc(ax, ay, 47, -0.42, 0, false);
    qctx.stroke();

    qctx.fillStyle = "#111827";
    qctx.font = "700 21px Inter, sans-serif";
    qctx.fillText(`θ = ${question.diagram.angle}${question.diagram.angle === "?" ? "" : "°"}`, ax + 56, ay - 13);
    if (question.diagram.adjacent !== null) {
      qctx.fillText(`adjacent = ${question.diagram.adjacent}`, 230, 235);
    }
    if (question.diagram.opposite !== null) {
      qctx.save();
      qctx.translate(495, 155);
      qctx.rotate(-Math.PI / 2);
      qctx.fillText(`opposite = ${question.diagram.opposite}`, 0, 0);
      qctx.restore();
    }
    if (question.diagram.hypotenuse !== null) {
      qctx.save();
      qctx.translate(250, 112);
      qctx.rotate(-0.42);
      qctx.fillText(`hypotenuse = ${question.diagram.hypotenuse}`, 0, 0);
      qctx.restore();
    }
  }

  function recordAnswer(player, question, selectedIndex, outcome, now, answeredBy) {
    const responseTimeMs = Math.max(0, Math.round(now - question.createdAt));
    const isCorrect = outcome === "correct";
    const timedOut = outcome === "timeout";
    if (outcome !== "match-ended") {
      player.questionStats.attempts += 1;
      player.questionStats.totalResponseMs += responseTimeMs;
      if (isCorrect) player.questionStats.correct += 1;
      else if (timedOut) player.questionStats.timeouts += 1;
      else player.questionStats.wrong += 1;
    }
    player.questionStats.answers.push({
      questionId: question.id,
      deathNumber: question.deathNumber,
      type: question.type,
      prompt: question.prompt,
      options: [...question.options],
      selectedIndex,
      selectedAnswer: selectedIndex == null ? null : question.options[selectedIndex],
      correctIndex: question.correctIndex,
      correctAnswer: question.correctAnswer,
      correct: isCorrect,
      timedOut,
      outcome,
      answeredBy,
      presentedAt: Math.round(question.createdAt),
      answeredAt: Math.round(now),
      responseTimeMs
    });
  }

  function resolveQuestion(player, selectedIndex, outcome, now, answeredBy) {
    const question = player.question;
    if (!question || question.resolved) return false;
    question.resolved = true;
    recordAnswer(player, question, selectedIndex, outcome, now, answeredBy);
    player.question = null;

    if (outcome === "correct") {
      respawnPlayer(player, now);
    } else if (gameState === "running") {
      player.questionSequence += 1;
      createRespawnQuestion(player, now + 10);
    }
    return true;
  }

  function submitHumanAnswer(index) {
    const human = getHumanPlayer();
    if (!human || !human.question || humanQuestionLocked || gameState !== "running") return;
    humanQuestionLocked = true;
    const question = human.question;
    const correct = index === question.correctIndex;
    [...ui.questionOptions.children].forEach((button) => { button.disabled = true; });
    ui.questionFeedback.textContent = correct
      ? "Correct. Respawn authorized."
      : `Not correct. The answer was ${question.correctAnswer}${question.type === "inverse" ? "°" : " units"}. New question incoming.`;
    ui.questionFeedback.className = `question-feedback ${correct ? "correct" : "wrong"}`;
    playTone(correct ? 660 : 160, correct ? 0.12 : 0.16, correct ? "triangle" : "sawtooth", 0.045);

    setTimeout(() => {
      if (gameState !== "running") return;
      humanQuestion = null;
      ui.questionOverlay.classList.remove("visible");
      resolveQuestion(human, index, correct ? "correct" : "wrong", performance.now(), "human");
      if (human.question) {
        humanQuestion = human.question;
        humanQuestionLocked = false;
        renderHumanQuestion(human.question);
        ui.questionOverlay.classList.add("visible");
      }
    }, correct ? 700 : 1200);
  }

  function updateQuestions(now) {
    for (const player of players) {
      if (player.alive || !player.question) continue;
      const question = player.question;
      if (player.isHuman) {
        const remaining = Math.max(0, question.expiresAt - now);
        ui.questionTimer.textContent = String(Math.ceil(remaining / 1000));
        ui.questionTimer.style.borderColor = remaining < 6000 ? "#f04438" : "#d0d5dd";
        if (remaining <= 0 && !humanQuestionLocked) {
          humanQuestionLocked = true;
          [...ui.questionOptions.children].forEach((button) => { button.disabled = true; });
          ui.questionFeedback.textContent = "Time expired. New question incoming.";
          ui.questionFeedback.className = "question-feedback wrong";
          playTone(120, 0.18, "sawtooth", 0.04);
          setTimeout(() => {
            if (gameState !== "running") return;
            humanQuestion = null;
            ui.questionOverlay.classList.remove("visible");
            resolveQuestion(player, null, "timeout", performance.now(), "human");
            if (player.question) {
              humanQuestion = player.question;
              humanQuestionLocked = false;
              renderHumanQuestion(player.question);
              ui.questionOverlay.classList.add("visible");
            }
          }, 850);
        }
      } else if (now >= question.botAnswerAt) {
        const correct = Math.random() < CONFIG.botAccuracy;
        const selectedIndex = correct
          ? question.correctIndex
          : (question.correctIndex + 1 + Math.floor(Math.random() * 3)) % question.options.length;
        resolveQuestion(player, selectedIndex, correct ? "correct" : "wrong", now, "bot");
      } else if (now >= question.expiresAt) {
        resolveQuestion(player, null, "timeout", now, "bot");
      }
    }
  }

  function safeRespawnPoint(team) {
    const owned = [];
    for (let row = 0; row < CONFIG.rows; row += 1) {
      for (let col = 0; col < CONFIG.cols; col += 1) {
        if (territory[cellIndex(col, row)] === team && Math.random() < 0.05) {
          owned.push({ x: (col + 0.5) * cellWidth, y: (row + 0.5) * cellHeight });
        }
      }
    }
    owned.sort(() => Math.random() - 0.5);
    for (const point of owned) {
      if (players.every((player) => !player.alive || player.team === team || distanceSq(point.x, point.y, player.x, player.y) > 330 * 330)) {
        return point;
      }
    }
    return {
      x: randomRange(250, CONFIG.worldWidth - 250),
      y: randomRange(220, CONFIG.worldHeight - 220)
    };
  }

  function respawnPlayer(player, now) {
    const point = safeRespawnPoint(player.team);
    player.x = point.x;
    player.y = point.y;
    player.prevX = point.x;
    player.prevY = point.y;
    player.vx = 0;
    player.vy = 0;
    player.alive = true;
    player.shieldUntil = now + CONFIG.respawnShieldMs;
    player.shotReadyAt = now + 350;
    player.dashReadyAt = now + 550;
    claimCircle(player.team, player.x, player.y, 2, player);
    showBanner(`${player.name} solved the trigonometry gate and respawned`);
    if (player.isHuman) {
      humanQuestion = null;
      ui.questionOverlay.classList.remove("visible");
      ui.playerStateLabel.textContent = TEAM_DEFS[player.team].name;
    }
  }

  function updateGame(dt, now) {
    if (gameState !== "running") return;
    const human = getHumanPlayer();
    updateHumanInput(human, now);
    updateBots(now);
    movePlayers(dt, now);
    updateProjectiles(dt, now);
    updateParticles(dt, now);
    updateQuestions(now);

    const elapsed = now - matchStartedAt;
    if (elapsed >= CONFIG.matchDurationMs) endMatch(now);
  }

  function endMatch(now) {
    if (gameState !== "running") return;
    gameState = "ended";
    matchEndedAt = now;
    for (const player of players) {
      if (player.question && !player.question.resolved) {
        player.question.resolved = true;
        recordAnswer(player, player.question, null, "match-ended", now, player.isHuman ? "human" : "bot");
        player.question = null;
      }
    }
    humanQuestion = null;
    ui.questionOverlay.classList.remove("visible");
    currentReport = buildReport();
    try {
      localStorage.setItem("triad-territory-last-report", JSON.stringify(currentReport));
    } catch (_) {}
    renderEndReport(currentReport);
    ui.endOverlay.classList.add("visible");
    ui.phaseLabel.textContent = "FINAL";
    playTone(523, 0.16, "triangle", 0.04);
    setTimeout(() => playTone(659, 0.16, "triangle", 0.04), 140);
    setTimeout(() => playTone(784, 0.24, "triangle", 0.04), 280);
  }

  function buildReport() {
    const totalCells = territory.length;
    const ranking = TEAM_DEFS.map((team) => ({
      team: team.id,
      teamName: team.name,
      territoryCells: territoryCounts[team.id],
      territoryPercent: territoryCounts[team.id] / totalCells,
      eliminations: teamKills[team.id]
    })).sort((a, b) => b.territoryCells - a.territoryCells || b.eliminations - a.eliminations || a.team - b.team);

    return {
      game: "Triad Territory Rush",
      version: "20.0.0-static-pages",
      mode: "one-human-eight-autonomous",
      winCondition: "largest-territory",
      startedAt: new Date(Date.now() - (performance.now() - matchStartedAt)).toISOString(),
      endedAt: new Date().toISOString(),
      durationMs: CONFIG.matchDurationMs,
      winner: ranking[0],
      ranking,
      players: players.map((player) => {
        const attempts = player.questionStats.attempts;
        return {
          playerId: player.id,
          slot: player.slot + 1,
          name: player.name,
          team: player.team,
          teamName: TEAM_DEFS[player.team].name,
          isHuman: player.isHuman,
          eliminations: player.kills,
          deaths: player.deaths,
          territoryCellsClaimed: player.territoryClaimed,
          questionSummary: {
            attempts,
            correct: player.questionStats.correct,
            wrong: player.questionStats.wrong,
            timeouts: player.questionStats.timeouts,
            accuracy: attempts > 0 ? player.questionStats.correct / attempts : 0,
            averageResponseMs: attempts > 0 ? Math.round(player.questionStats.totalResponseMs / attempts) : 0
          },
          answers: player.questionStats.answers.map((answer) => ({ ...answer, options: [...answer.options] }))
        };
      })
    };
  }

  function renderEndReport(report) {
    const winner = report.winner;
    ui.endTitle.textContent = `${winner.teamName} wins`;
    ui.winnerSummary.textContent = `${winner.teamName} controlled ${formatPercent(winner.territoryPercent)} of the arena. Territory is the only victory condition; eliminations are tactical support.`;
    ui.finalRanking.innerHTML = report.ranking.map((entry, index) => `
      <article class="rank-card ${index === 0 ? "winner" : ""}" style="border-top:4px solid ${TEAM_DEFS[entry.team].color}">
        <span>${index + 1}${index === 0 ? " · WINNER" : ""}</span>
        <b>${escapeHtml(entry.teamName)}</b>
        <span>${formatPercent(entry.territoryPercent)} territory · ${entry.eliminations} eliminations</span>
      </article>
    `).join("");

    ui.reportTableBody.innerHTML = report.players.map((player) => {
      const summary = player.questionSummary;
      return `
        <tr>
          <td><b>${escapeHtml(player.name)}</b>${player.isHuman ? " · YOU" : ""}</td>
          <td>${escapeHtml(player.teamName)}</td>
          <td>${player.territoryCellsClaimed}</td>
          <td>${player.deaths}</td>
          <td>${summary.attempts}</td>
          <td>${summary.correct}</td>
          <td>${summary.wrong}</td>
          <td>${summary.timeouts}</td>
          <td>${summary.attempts ? formatPercent(summary.accuracy) : "—"}</td>
          <td>${summary.attempts ? `${(summary.averageResponseMs / 1000).toFixed(1)} s` : "—"}</td>
        </tr>
      `;
    }).join("");
  }

  function csvEscape(value) {
    const text = value == null ? "" : String(value);
    return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  }

  function reportToCsv(report) {
    const headers = [
      "match_started_at", "match_ended_at", "winner_team", "player_id", "player_name", "team", "is_human",
      "territory_cells_claimed", "eliminations", "deaths", "attempts", "correct", "wrong", "timeouts", "accuracy",
      "average_response_ms", "death_number", "question_type", "question_prompt", "selected_answer", "correct_answer",
      "answer_correct", "outcome", "response_time_ms"
    ];
    const rows = [headers];
    for (const player of report.players) {
      const answers = player.answers.length ? player.answers : [null];
      for (const answer of answers) {
        rows.push([
          report.startedAt,
          report.endedAt,
          report.winner.teamName,
          player.playerId,
          player.name,
          player.teamName,
          player.isHuman,
          player.territoryCellsClaimed,
          player.eliminations,
          player.deaths,
          player.questionSummary.attempts,
          player.questionSummary.correct,
          player.questionSummary.wrong,
          player.questionSummary.timeouts,
          player.questionSummary.accuracy.toFixed(4),
          player.questionSummary.averageResponseMs,
          answer?.deathNumber ?? "",
          answer?.type ?? "",
          answer?.prompt ?? "",
          answer?.selectedAnswer ?? "",
          answer?.correctAnswer ?? "",
          answer?.correct ?? "",
          answer?.outcome ?? "",
          answer?.responseTimeMs ?? ""
        ]);
      }
    }
    return rows.map((row) => row.map(csvEscape).join(",")).join("\n");
  }

  function downloadBlob(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function updateHud(now) {
    const human = getHumanPlayer();
    const remaining = gameState === "running" ? CONFIG.matchDurationMs - (now - matchStartedAt) : gameState === "ended" ? 0 : CONFIG.matchDurationMs;
    ui.clockLabel.textContent = formatTime(remaining);
    if (!human) return;

    ui.playerNameLabel.textContent = human.name;
    ui.playerTeamDot.style.background = TEAM_DEFS[human.team].color;
    ui.playerStateLabel.textContent = human.alive ? TEAM_DEFS[human.team].name : "Eliminated · solve to respawn";
    ui.playerTerritoryLabel.textContent = String(human.territoryClaimed);
    ui.playerKillsLabel.textContent = String(human.kills);
    ui.playerDeathsLabel.textContent = String(human.deaths);
    const accuracy = accuracyOf(human);
    ui.playerAccuracyLabel.textContent = accuracy == null ? "—" : formatPercent(accuracy);
    ui.shotCooldown.value = clamp(1 - (human.shotReadyAt - now) / CONFIG.shotCooldownMs, 0, 1);
    ui.dashCooldown.value = clamp(1 - (human.dashReadyAt - now) / CONFIG.dashCooldownMs, 0, 1);

    const totalCells = territory.length;
    for (let team = 0; team < 3; team += 1) {
      ui.teamTerritory[team].textContent = formatPercent(territoryCounts[team] / totalCells);
      ui.teamKills[team].textContent = String(teamKills[team]);
    }
  }

  function updateCamera(dt) {
    const human = getHumanPlayer();
    if (!human) return;
    const targetX = human.x;
    const targetY = human.y;
    const smooth = 1 - Math.pow(0.001, dt);
    camera.x = lerp(camera.x, targetX, smooth);
    camera.y = lerp(camera.y, targetY, smooth);
    const halfWorldW = canvasCssWidth / (2 * camera.zoom);
    const halfWorldH = canvasCssHeight / (2 * camera.zoom);
    camera.x = clamp(camera.x, Math.min(halfWorldW, CONFIG.worldWidth / 2), Math.max(CONFIG.worldWidth - halfWorldW, CONFIG.worldWidth / 2));
    camera.y = clamp(camera.y, Math.min(halfWorldH, CONFIG.worldHeight / 2), Math.max(CONFIG.worldHeight - halfWorldH, CONFIG.worldHeight / 2));
    const worldMouse = screenToWorld(mouse.x, mouse.y);
    mouse.worldX = worldMouse.x;
    mouse.worldY = worldMouse.y;
  }

  function visibleCellRange() {
    const halfW = canvasCssWidth / (2 * camera.zoom);
    const halfH = canvasCssHeight / (2 * camera.zoom);
    return {
      minCol: clamp(Math.floor((camera.x - halfW) / cellWidth) - 1, 0, CONFIG.cols - 1),
      maxCol: clamp(Math.ceil((camera.x + halfW) / cellWidth) + 1, 0, CONFIG.cols - 1),
      minRow: clamp(Math.floor((camera.y - halfH) / cellHeight) - 1, 0, CONFIG.rows - 1),
      maxRow: clamp(Math.ceil((camera.y + halfH) / cellHeight) + 1, 0, CONFIG.rows - 1)
    };
  }

  function drawArena(now) {
    ctx.setTransform(deviceScale, 0, 0, deviceScale, 0, 0);
    ctx.fillStyle = "#f4f6f9";
    ctx.fillRect(0, 0, canvasCssWidth, canvasCssHeight);

    ctx.save();
    ctx.translate(canvasCssWidth / 2, canvasCssHeight / 2);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-camera.x, -camera.y);

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, CONFIG.worldWidth, CONFIG.worldHeight);

    const range = visibleCellRange();
    for (let row = range.minRow; row <= range.maxRow; row += 1) {
      for (let col = range.minCol; col <= range.maxCol; col += 1) {
        const owner = territory[cellIndex(col, row)];
        if (owner < 0) continue;
        ctx.fillStyle = TEAM_DEFS[owner].pale;
        ctx.globalAlpha = 0.65;
        ctx.fillRect(col * cellWidth, row * cellHeight, cellWidth + 0.5, cellHeight + 0.5);
      }
    }
    ctx.globalAlpha = 1;

    ctx.strokeStyle = "rgba(17,24,39,0.055)";
    ctx.lineWidth = 1 / camera.zoom;
    ctx.beginPath();
    for (let col = range.minCol; col <= range.maxCol + 1; col += 1) {
      ctx.moveTo(col * cellWidth, range.minRow * cellHeight);
      ctx.lineTo(col * cellWidth, (range.maxRow + 1) * cellHeight);
    }
    for (let row = range.minRow; row <= range.maxRow + 1; row += 1) {
      ctx.moveTo(range.minCol * cellWidth, row * cellHeight);
      ctx.lineTo((range.maxCol + 1) * cellWidth, row * cellHeight);
    }
    ctx.stroke();

    drawArenaDecorations();
    drawProjectiles();
    drawPlayers(now);
    drawParticles(now);

    ctx.strokeStyle = "#111827";
    ctx.lineWidth = 5 / camera.zoom;
    ctx.strokeRect(0, 0, CONFIG.worldWidth, CONFIG.worldHeight);
    ctx.restore();
  }

  function drawArenaDecorations() {
    const centerX = CONFIG.worldWidth / 2;
    const centerY = CONFIG.worldHeight / 2;
    ctx.save();
    ctx.strokeStyle = "rgba(17,24,39,0.12)";
    ctx.lineWidth = 4;
    ctx.setLineDash([28, 22]);
    ctx.beginPath();
    ctx.arc(centerX, centerY, 430, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    const nodes = [
      { x: centerX, y: centerY - 390 },
      { x: centerX - 430, y: centerY + 290 },
      { x: centerX + 430, y: centerY + 290 }
    ];
    ctx.strokeStyle = "rgba(17,24,39,0.10)";
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    for (const node of nodes) {
      ctx.beginPath();
      ctx.arc(node.x, node.y, 82, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawPlayers(now) {
    for (const player of players) {
      if (!player.alive) continue;
      const team = TEAM_DEFS[player.team];
      ctx.save();
      ctx.translate(player.x, player.y);
      ctx.rotate(player.angle);

      if (now < player.shieldUntil) {
        ctx.strokeStyle = team.color;
        ctx.globalAlpha = 0.55 + Math.sin(now / 70) * 0.2;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(0, 0, 29, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      ctx.fillStyle = team.color;
      ctx.strokeStyle = player.isHuman ? "#111827" : team.dark;
      ctx.lineWidth = player.isHuman ? 4 : 2.5;
      ctx.beginPath();
      ctx.moveTo(25, 0);
      ctx.lineTo(-15, -16);
      ctx.lineTo(-9, 0);
      ctx.lineTo(-15, 16);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(4, 0, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.fillStyle = "rgba(17,24,39,0.88)";
      ctx.font = `${player.isHuman ? "800" : "700"} 14px Inter, sans-serif`;
      ctx.textAlign = "center";
      ctx.fillText(player.name, player.x, player.y - 31);
      if (!player.isHuman) {
        ctx.font = "700 10px Inter, sans-serif";
        ctx.fillStyle = "rgba(71,84,103,0.9)";
        ctx.fillText("AI", player.x, player.y + 36);
      }
      ctx.restore();
    }
  }

  function drawProjectiles() {
    for (const projectile of projectiles) {
      const team = TEAM_DEFS[projectile.team];
      ctx.save();
      ctx.fillStyle = team.color;
      ctx.shadowColor = team.color;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(projectile.x, projectile.y, projectile.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawParticles(now) {
    for (const particle of particles) {
      const life = clamp(1 - (now - particle.bornAt) / particle.life, 0, 1);
      ctx.save();
      ctx.globalAlpha = life;
      ctx.fillStyle = particle.color;
      ctx.fillRect(particle.x - particle.size / 2, particle.y - particle.size / 2, particle.size, particle.size);
      ctx.restore();
    }
  }

  function drawMinimap() {
    const width = minimapCanvas.width;
    const height = minimapCanvas.height;
    mctx.fillStyle = "#ffffff";
    mctx.fillRect(0, 0, width, height);
    const sx = width / CONFIG.worldWidth;
    const sy = height / CONFIG.worldHeight;

    for (let row = 0; row < CONFIG.rows; row += 1) {
      for (let col = 0; col < CONFIG.cols; col += 1) {
        const owner = territory[cellIndex(col, row)];
        if (owner < 0) continue;
        mctx.fillStyle = TEAM_DEFS[owner].pale;
        mctx.fillRect(col * cellWidth * sx, row * cellHeight * sy, cellWidth * sx + 0.5, cellHeight * sy + 0.5);
      }
    }

    for (const player of players) {
      if (!player.alive) continue;
      mctx.fillStyle = TEAM_DEFS[player.team].color;
      mctx.beginPath();
      mctx.arc(player.x * sx, player.y * sy, player.isHuman ? 4.5 : 3, 0, Math.PI * 2);
      mctx.fill();
      if (player.isHuman) {
        mctx.strokeStyle = "#111827";
        mctx.lineWidth = 1.5;
        mctx.stroke();
      }
    }

    const viewWorldW = canvasCssWidth / camera.zoom;
    const viewWorldH = canvasCssHeight / camera.zoom;
    mctx.strokeStyle = "rgba(17,24,39,0.45)";
    mctx.lineWidth = 1;
    mctx.strokeRect((camera.x - viewWorldW / 2) * sx, (camera.y - viewWorldH / 2) * sy, viewWorldW * sx, viewWorldH * sy);
  }

  function frame(now) {
    const dt = Math.min(0.05, Math.max(0, (now - lastFrameAt) / 1000));
    lastFrameAt = now;
    updateGame(dt, now);
    updateCamera(dt);
    updateHud(now);
    drawArena(now);
    drawMinimap();
    requestAnimationFrame(frame);
  }

  function keyToInput(code, pressed) {
    if (code === "KeyW" || code === "ArrowUp") input.up = pressed;
    if (code === "KeyS" || code === "ArrowDown") input.down = pressed;
    if (code === "KeyA" || code === "ArrowLeft") input.left = pressed;
    if (code === "KeyD" || code === "ArrowRight") input.right = pressed;
    if (code === "Space" && pressed) input.fire = true;
    if ((code === "ShiftLeft" || code === "ShiftRight") && pressed) input.dash = true;
  }

  window.addEventListener("keydown", (event) => {
    if (["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "ShiftLeft", "ShiftRight"].includes(event.code)) {
      event.preventDefault();
      keyToInput(event.code, true);
    }
  }, { passive: false });

  window.addEventListener("keyup", (event) => {
    keyToInput(event.code, false);
  });

  canvas.addEventListener("mousemove", (event) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = event.clientX - rect.left;
    mouse.y = event.clientY - rect.top;
  });

  canvas.addEventListener("mousedown", (event) => {
    if (event.button === 0) input.fire = true;
  });

  canvas.addEventListener("contextmenu", (event) => event.preventDefault());

  ui.startButton.addEventListener("click", startMatch);
  ui.playAgainButton.addEventListener("click", () => {
    ui.endOverlay.classList.remove("visible");
    ui.lobbyOverlay.classList.add("visible");
    gameState = "lobby";
    ui.phaseLabel.textContent = "LOBBY";
    ui.clockLabel.textContent = "05:00";
  });

  ui.downloadCsvButton.addEventListener("click", () => {
    if (!currentReport) return;
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    downloadBlob(`triad-territory-report-${stamp}.csv`, reportToCsv(currentReport), "text/csv;charset=utf-8");
  });

  ui.downloadJsonButton.addEventListener("click", () => {
    if (!currentReport) return;
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    downloadBlob(`triad-territory-report-${stamp}.json`, JSON.stringify(currentReport, null, 2), "application/json;charset=utf-8");
  });

  ui.soundButton.addEventListener("click", () => {
    soundEnabled = !soundEnabled;
    ui.soundButton.textContent = soundEnabled ? "SOUND ON" : "SOUND OFF";
    ui.soundButton.setAttribute("aria-pressed", String(soundEnabled));
    if (soundEnabled) playTone(440, 0.08, "sine", 0.025);
  });

  window.addEventListener("resize", resizeCanvas);
  resizeCanvas();
  requestAnimationFrame(frame);
})();
