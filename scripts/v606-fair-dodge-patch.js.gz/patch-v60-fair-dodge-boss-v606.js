"use strict";
const fs = require("node:fs");
const path = require("node:path");
const root = path.join(__dirname, "..");
const gamePath = path.join(root, "school-game", "v60", "game.js");
const htmlPath = path.join(root, "school-game", "v60", "index.html");
const mainPath = path.join(root, "school-game", "v60", "main.js");
function replaceRequired(source,before,after,label){ if(!source.includes(before)) throw new Error(`V60.6 patch missing ${label}`); return source.replace(before,after); }
function replaceAllRequired(source,before,after,label){ if(!source.includes(before)) throw new Error(`V60.6 patch missing ${label}`); return source.split(before).join(after); }
let game=fs.readFileSync(gamePath,"utf8");
game=replaceRequired(game,'const VERSION = "60.5.0";','const VERSION = "60.6.0";',"renderer version");
game=replaceRequired(game,'const EDITION = "math-factorization-relentless-boss-v605";','const EDITION = "math-factorization-fair-dodge-boss-v606";',"renderer edition");
const oldConst=`  const BOSS_SHIELD_HITS_BY_PHASE = Object.freeze([4, 5, 6]);
  const BOSS_DASHES_BY_PHASE = Object.freeze([3, 5, 7]);
  const BOSS_DASH_SPEED_BY_PHASE = Object.freeze([760, 940, 1120]);
  const BOSS_DASH_TELEGRAPH_BY_PHASE = Object.freeze([0.34, 0.24, 0.16]);
  const BOSS_DASH_DURATION_BY_PHASE = Object.freeze([0.27, 0.30, 0.33]);
  const BOSS_DASH_CHAIN_GAP_BY_PHASE = Object.freeze([0.16, 0.11, 0.07]);
  const BOSS_FATIGUE_SECONDS_BY_PHASE = Object.freeze([2.25, 1.55, 0.95]);
  const BOSS_PREDICTION_SECONDS_BY_PHASE = Object.freeze([0.24, 0.42, 0.62]);
  const BOSS_DASH_STEER_BY_PHASE = Object.freeze([0.0, 0.58, 1.15]);
  const BOSS_ROOM_PICKUP_RADIUS = 118;`;
const newConst=`  const BOSS_SHIELD_HITS_BY_PHASE = Object.freeze([4, 5, 6]);
  const BOSS_DASHES_BY_PHASE = Object.freeze([3, 5, 7]);
  const BOSS_DASH_SPEED_BY_PHASE = Object.freeze([740, 900, 1040]);
  const BOSS_DASH_TELEGRAPH_BY_PHASE = Object.freeze([0.76, 0.62, 0.50]);
  const BOSS_DASH_LOCK_SECONDS_BY_PHASE = Object.freeze([0.24, 0.20, 0.17]);
  const BOSS_DASH_DURATION_BY_PHASE = Object.freeze([0.25, 0.27, 0.29]);
  const BOSS_DASH_CHAIN_GAP_BY_PHASE = Object.freeze([0.34, 0.30, 0.27]);
  const BOSS_FATIGUE_SECONDS_BY_PHASE = Object.freeze([2.80, 2.35, 1.90]);
  const BOSS_PREDICTION_SECONDS_BY_PHASE = Object.freeze([0.22, 0.36, 0.50]);
  const BOSS_DASH_STEER_BY_PHASE = Object.freeze([0, 0, 0]);
  const BOSS_DODGE_IFRAMES_SECONDS = 0.30;
  const BOSS_DODGE_COOLDOWN_SECONDS = 0.42;
  const BOSS_ROOM_PICKUP_RADIUS = 118;`;
game=replaceRequired(game,oldConst,newConst,"fair boss constants");

game=replaceRequired(game,
`      bossDashTargetX: x, bossDashTargetY: y,
      bossDashHitRegistered: false,
      bossDashChainRemaining: typeId === "boss" ? BOSS_DASHES_BY_PHASE[0] : 0,`,
`      bossDashTargetX: x, bossDashTargetY: y,
      bossDashHitRegistered: false,
      bossDashTelegraphMax: 0,
      bossDashAimLocked: false,
      bossPerfectDodges: 0,
      bossDashChainRemaining: typeId === "boss" ? BOSS_DASHES_BY_PHASE[0] : 0,`,
"boss telegraph fields");

game=replaceRequired(game,
`    enemy.bossDashTimer = 0;
    enemy.bossDashTelegraph = 0;
    enemy.bossDashVX = 0;`,
`    enemy.bossDashTimer = 0;
    enemy.bossDashTelegraph = 0;
    enemy.bossDashTelegraphMax = 0;
    enemy.bossDashAimLocked = false;
    enemy.bossDashVX = 0;`,
"fatigue aim reset");

game=replaceRequired(game,
`    enemy.bossRushActive = true;
    enemy.bossFatigueTimer = 0;
    enemy.bossDashChainTotal = count;`,
`    enemy.bossRushActive = true;
    enemy.bossFatigueTimer = 0;
    enemy.bossDashAimLocked = false;
    enemy.bossDashChainTotal = count;`,
"rush aim reset");

game=replaceRequired(game,
`  function fireBossDashPressure(enemy, player, stage = "launch") {
    const phase = clamp(enemy.bossPhase, 1, BOSS_PHASES);
    const predicted = bossPredictiveAngle(enemy, player, stage === "launch" ? 1.18 : 0.92);
    if (phase === 1) {
      if (stage === "launch") spawnProjectile("enemy", enemy.x, enemy.y, predicted, "precision", enemy.id);
      return;
    }
    if (phase === 2) {
      const offsets = stage === "launch" ? [-0.07, 0, 0.07] : [-0.14, 0.14];
      for (const offset of offsets) spawnProjectile("enemy", enemy.x, enemy.y, predicted + offset, stage === "launch" ? "precision" : "heavy", enemy.id);
      return;
    }
    if (stage === "launch") {
      for (let i = -3; i <= 3; i++) spawnProjectile("enemy", enemy.x, enemy.y, predicted + i * 0.055, "smg", enemy.id);
    } else {
      for (let i = 0; i < 12; i++) spawnProjectile("enemy", enemy.x, enemy.y, i * Math.PI * 2 / 12 + enemy.bossOrbit, "scatter", enemy.id);
    }
  }`,
`  function fireBossDashPressure(enemy, player, stage = "launch") {
    if (stage !== "impact" || !enemy?.bossShieldActive) return;
    const phase = clamp(enemy.bossPhase, 1, BOSS_PHASES);
    const predicted = bossPredictiveAngle(enemy, player, 0.66);
    if (phase === 1) return;
    if (phase === 2) {
      for (const offset of [-0.34, 0.34]) spawnProjectile("enemy", enemy.x, enemy.y, predicted + offset, "precision", enemy.id);
      return;
    }
    for (const offset of [-0.52, -0.27, 0.27, 0.52]) spawnProjectile("enemy", enemy.x, enemy.y, predicted + offset, "scatter", enemy.id);
  }`,
"fair projectile pressure");

game=replaceRequired(game,
`  function beginBossDash(enemy, player, opening = false) {
    const phaseIndex = bossPhaseIndex(enemy);
    const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.12);
    enemy.bossDashTargetX = predicted.x;
    enemy.bossDashTargetY = predicted.y;
    const baseTelegraph = BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex];
    enemy.bossDashTelegraph = opening ? Math.max(0.12, baseTelegraph * 0.55) : baseTelegraph;
    enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
    enemy.bossDashHitRegistered = false;
    enemy.bossRushActive = true;
    enemy.bossDashChainRemaining = Math.max(0, (enemy.bossDashChainRemaining || bossDashCountForPhase(enemy)) - 1);
    enemy.action = "charge";
    enemy.actionTimer = enemy.bossDashTelegraph;
    fireBossDashPressure(enemy, player, "launch");
    banner(\`WARDEN DASH \${enemy.bossDashChainTotal - enemy.bossDashChainRemaining}/\${enemy.bossDashChainTotal} · PHASE \${enemy.bossPhase}\`, 650);
    for (let i = 0; i < 18; i++) createParticle(enemy.x, enemy.y, "spark", "#b6405b");
    tone(140 - phaseIndex * 15, 0.09, 0.035, "sawtooth");
  }`,
`  function beginBossDash(enemy, player, opening = false) {
    const phaseIndex = bossPhaseIndex(enemy);
    const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.10);
    enemy.bossDashTargetX = predicted.x;
    enemy.bossDashTargetY = predicted.y;
    const baseTelegraph = BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex];
    enemy.bossDashTelegraph = opening ? Math.max(1.05, baseTelegraph) : baseTelegraph;
    enemy.bossDashTelegraphMax = enemy.bossDashTelegraph;
    enemy.bossDashAimLocked = false;
    enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
    enemy.bossDashHitRegistered = false;
    enemy.bossRushActive = true;
    enemy.bossDashChainRemaining = Math.max(0, (enemy.bossDashChainRemaining || bossDashCountForPhase(enemy)) - 1);
    enemy.action = "charge";
    enemy.actionTimer = enemy.bossDashTelegraph;
    banner(\`WARDEN AIM \${enemy.bossDashChainTotal - enemy.bossDashChainRemaining}/\${enemy.bossDashChainTotal} · WATCH THE RED LANE · TAP SHIFT ON LOCK\`, opening ? 1300 : 780);
    for (let i = 0; i < 14; i++) createParticle(enemy.x, enemy.y, "spark", "#d89000");
    tone(210 - phaseIndex * 18, 0.07, 0.028, "triangle");
  }`,
"fair dash start");

// Replace dash execution block (remove unfair in-dash steering + reward perfect dodge)
game=replaceRequired(game,
`    if (enemy.bossDashTimer > 0) {
      enemy.bossDashTimer = Math.max(0, enemy.bossDashTimer - dt);
      enemy.action = "dash";
      const phaseIndex = bossPhaseIndex(enemy);
      const steerStrength = BOSS_DASH_STEER_BY_PHASE[phaseIndex];
      if (steerStrength > 0) {
        const predicted = bossPredictedPoint(enemy, player, 0.42 + phaseIndex * 0.14);
        const desired = normalize(predicted.x - enemy.x, predicted.y - enemy.y);
        const speed = BOSS_DASH_SPEED_BY_PHASE[phaseIndex];
        const blend = clamp(steerStrength * dt, 0, 0.18);
        enemy.bossDashVX = enemy.bossDashVX * (1 - blend) + desired.x * speed * blend;
        enemy.bossDashVY = enemy.bossDashVY * (1 - blend) + desired.y * speed * blend;
      }
      enemy.vx = enemy.bossDashVX;
      enemy.vy = enemy.bossDashVY;
      moveCircle(enemy, enemy.vx * dt, enemy.vy * dt);
      enemy.facing = Math.atan2(enemy.vy, enemy.vx);
      if (!enemy.bossDashHitRegistered && Math.hypot(player.x - enemy.x, player.y - enemy.y) <= enemy.radius + player.radius + 18) {
        enemy.bossDashHitRegistered = true;
        registerPlayerStrike({ color: "#b6405b", weaponId: \`boss-dash-phase-\${enemy.bossPhase}\` });
        banner(\`WARDEN DASH HIT · PHASE \${enemy.bossPhase}\`, 700);
      }
      if (enemy.bossDashTimer <= 0) {
        fireBossDashPressure(enemy, player, "impact");
        if (enemy.bossDashChainRemaining > 0 && enemy.bossShieldActive) {
          enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
        } else if (enemy.bossShieldActive) {
          enterBossFatigue(enemy);
        }
      }
      return;
    }`,
`    if (enemy.bossDashTimer > 0) {
      enemy.bossDashTimer = Math.max(0, enemy.bossDashTimer - dt);
      enemy.action = "dash";
      const phaseIndex = bossPhaseIndex(enemy);
      enemy.vx = enemy.bossDashVX;
      enemy.vy = enemy.bossDashVY;
      moveCircle(enemy, enemy.vx * dt, enemy.vy * dt);
      enemy.facing = Math.atan2(enemy.vy, enemy.vx);
      if (!enemy.bossDashHitRegistered && Math.hypot(player.x - enemy.x, player.y - enemy.y) <= enemy.radius + player.radius + 18) {
        enemy.bossDashHitRegistered = true;
        if (player.invulnerable > 0 && player.dashTimer > 0) {
          enemy.bossPerfectDodges = (enemy.bossPerfectDodges || 0) + 1;
          state.bossPerfectDodges = (state.bossPerfectDodges || 0) + 1;
          const shieldWasActive = enemy.bossShieldActive;
          if (shieldWasActive) damageBossShield(enemy, 1, "PERFECT DODGE");
          banner(shieldWasActive ? \`PERFECT DODGE · WARDEN OVEREXTENDS · SHIELD \${enemy.bossShieldHits}/\${enemy.bossShieldMaxHits}\` : "PERFECT DODGE · CORE WINDOW", 850);
          tone(920, 0.08, 0.026, "triangle");
        } else {
          registerPlayerStrike({ color: "#b6405b", weaponId: \`boss-dash-phase-\${enemy.bossPhase}\` });
          banner(\`WARDEN DASH HIT · TAP SHIFT INSIDE THE RED LOCK WINDOW\`, 900);
        }
      }
      if (!enemy.bossShieldActive) return;
      if (enemy.bossDashTimer <= 0) {
        fireBossDashPressure(enemy, player, "impact");
        if (enemy.bossDashChainRemaining > 0 && enemy.bossShieldActive) {
          enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
        } else if (enemy.bossShieldActive) {
          enterBossFatigue(enemy);
        }
      }
      return;
    }`,
"locked dash execution");

// Replace telegraph with visible-lock semantics
game=replaceRequired(game,
`    if (enemy.bossDashTelegraph > 0) {
      const phaseIndex = bossPhaseIndex(enemy);
      enemy.bossDashTelegraph = Math.max(0, enemy.bossDashTelegraph - dt);
      enemy.vx = 0; enemy.vy = 0;
      if (enemy.bossDashTelegraph > 0.07) {
        const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.12);
        const track = clamp(dt * (4.5 + phaseIndex * 2.1), 0, 0.34);
        enemy.bossDashTargetX += (predicted.x - enemy.bossDashTargetX) * track;
        enemy.bossDashTargetY += (predicted.y - enemy.bossDashTargetY) * track;
      }
      enemy.facing = Math.atan2(enemy.bossDashTargetY - enemy.y, enemy.bossDashTargetX - enemy.x);
      enemy.action = "charge";
      if (enemy.bossDashTelegraph <= 0) {
        const direction = normalize(enemy.bossDashTargetX - enemy.x, enemy.bossDashTargetY - enemy.y);
        const dashSpeed = BOSS_DASH_SPEED_BY_PHASE[phaseIndex];
        enemy.bossDashVX = direction.x * dashSpeed;
        enemy.bossDashVY = direction.y * dashSpeed;
        enemy.bossDashTimer = BOSS_DASH_DURATION_BY_PHASE[phaseIndex];
        enemy.bossDashHitRegistered = false;
        tone(92 - phaseIndex * 8, 0.075, 0.04, "square");
      }
      return;
    }`,
`    if (enemy.bossDashTelegraph > 0) {
      const phaseIndex = bossPhaseIndex(enemy);
      enemy.bossDashTelegraph = Math.max(0, enemy.bossDashTelegraph - dt);
      enemy.vx = 0; enemy.vy = 0;
      const lockSeconds = BOSS_DASH_LOCK_SECONDS_BY_PHASE[phaseIndex];
      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph > lockSeconds) {
        const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.10);
        const track = clamp(dt * (4.0 + phaseIndex * 1.6), 0, 0.28);
        enemy.bossDashTargetX += (predicted.x - enemy.bossDashTargetX) * track;
        enemy.bossDashTargetY += (predicted.y - enemy.bossDashTargetY) * track;
      }
      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph <= lockSeconds) {
        enemy.bossDashAimLocked = true;
        banner("DODGE NOW · AIM LOCKED · TAP SHIFT + MOVE", Math.ceil(lockSeconds * 1000));
        tone(1040, 0.055, 0.032, "square");
      }
      enemy.facing = Math.atan2(enemy.bossDashTargetY - enemy.y, enemy.bossDashTargetX - enemy.x);
      enemy.action = "charge";
      if (enemy.bossDashTelegraph <= 0) {
        const direction = normalize(enemy.bossDashTargetX - enemy.x, enemy.bossDashTargetY - enemy.y);
        const dashSpeed = BOSS_DASH_SPEED_BY_PHASE[phaseIndex];
        enemy.bossDashVX = direction.x * dashSpeed;
        enemy.bossDashVY = direction.y * dashSpeed;
        enemy.bossDashTimer = BOSS_DASH_DURATION_BY_PHASE[phaseIndex];
        enemy.bossDashHitRegistered = false;
        enemy.bossDashAimLocked = true;
        tone(92 - phaseIndex * 8, 0.075, 0.04, "square");
      }
      return;
    }`,
"aim lock telegraph");

// Boss-room dodge is a deliberate tap with enough i-frames for one committed lane.
game=replaceRequired(game,
`    if ((keys.has("ShiftLeft") || keys.has("ShiftRight")) && player.dashCooldown <= 0 && hasMoveInput) {
      player.dashCooldown = 1.25;
      player.dashTimer = 0.16;
      player.invulnerable = Math.max(player.invulnerable, 0.18);
      player.action = "dash";
      player.actionTimer = 0.2;
      tone(680, 0.05, 0.022, "sawtooth");
      for (let index = 0; index < 8; index++) createParticle(player.x, player.y, "dash", "#2457d6");
    }`,
`    if ((keys.has("ShiftLeft") || keys.has("ShiftRight")) && player.dashCooldown <= 0 && hasMoveInput) {
      const bossRoomDodge = MAPS[state.levelIndex].bossRoom;
      player.dashCooldown = bossRoomDodge ? BOSS_DODGE_COOLDOWN_SECONDS : 1.25;
      player.dashTimer = bossRoomDodge ? 0.22 : 0.16;
      player.invulnerable = Math.max(player.invulnerable, bossRoomDodge ? BOSS_DODGE_IFRAMES_SECONDS : 0.18);
      player.action = "dash";
      player.actionTimer = bossRoomDodge ? 0.24 : 0.2;
      if (bossRoomDodge) { keys.delete("ShiftLeft"); keys.delete("ShiftRight"); }
      tone(680, 0.05, 0.022, "sawtooth");
      for (let index = 0; index < (bossRoomDodge ? 12 : 8); index++) createParticle(player.x, player.y, "dash", "#2457d6");
    }`,
"boss room dodge timing");

game=replaceRequired(game,
`    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.code)) event.preventDefault();
    if (event.code === "F8" && !event.repeat) { event.preventDefault(); openTeacherModeMenu(); return; }`,
`    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.code)) event.preventDefault();
    if ((event.code === "ShiftLeft" || event.code === "ShiftRight") && event.repeat) return;
    if (event.code === "F8" && !event.repeat) { event.preventDefault(); openTeacherModeMenu(); return; }`,
"edge-trigger dodge key");

const drawInsert=`  function drawBossDashTelegraph() {
    const boss = state.enemies.find((enemy) => enemy.typeId === "boss" && !enemy.defeated);
    const player = state.player;
    if (!boss || !player || boss.bossDashTelegraph <= 0) return;
    const phaseIndex = bossPhaseIndex(boss);
    const direction = normalize(boss.bossDashTargetX - boss.x, boss.bossDashTargetY - boss.y);
    const laneLength = BOSS_DASH_SPEED_BY_PHASE[phaseIndex] * BOSS_DASH_DURATION_BY_PHASE[phaseIndex] + boss.radius * 2.4;
    const endX = boss.x + direction.x * laneLength;
    const endY = boss.y + direction.y * laneLength;
    const locked = Boolean(boss.bossDashAimLocked);
    const total = Math.max(0.001, boss.bossDashTelegraphMax || BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex]);
    const remainingRatio = clamp(boss.bossDashTelegraph / total, 0, 1);
    ctx.save();
    ctx.lineCap = "round";
    ctx.strokeStyle = locked ? "rgba(196,61,61,.28)" : "rgba(216,144,0,.18)";
    ctx.lineWidth = (boss.radius + player.radius) * 1.45;
    ctx.setLineDash(locked ? [] : [18, 14]);
    ctx.beginPath(); ctx.moveTo(boss.x, boss.y); ctx.lineTo(endX, endY); ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = locked ? "#c43d3d" : "#d89000";
    ctx.lineWidth = locked ? 5 : 3;
    ctx.beginPath(); ctx.moveTo(boss.x, boss.y); ctx.lineTo(endX, endY); ctx.stroke();
    ctx.fillStyle = locked ? "rgba(196,61,61,.14)" : "rgba(216,144,0,.10)";
    ctx.beginPath(); ctx.arc(endX, endY, 34, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = locked ? "#c43d3d" : "#d89000";
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(endX, endY, 30, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - remainingRatio)); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(endX - 18, endY); ctx.lineTo(endX + 18, endY); ctx.moveTo(endX, endY - 18); ctx.lineTo(endX, endY + 18); ctx.stroke();
    ctx.fillStyle = "rgba(17,24,39,.94)";
    roundedRect(ctx, player.x - 92, player.y - 84, 184, 29, 8); ctx.fill();
    ctx.fillStyle = locked ? "#fff" : "#f8d57e";
    ctx.font = "900 12px Segoe UI"; ctx.textAlign = "center";
    ctx.fillText(locked ? "DODGE NOW · TAP SHIFT" : "WARDEN AIMING · WAIT", player.x, player.y - 64);
    ctx.restore();
  }

  function drawBossDodgeStatus() {
    const player = state.player;
    if (!player || player.defeated || !MAPS[state.levelIndex].bossRoom) return;
    const ready = player.dashCooldown <= 0;
    ctx.save();
    ctx.fillStyle = ready ? "rgba(20,110,78,.92)" : "rgba(17,24,39,.82)";
    roundedRect(ctx, player.x - 76, player.y + 40, 152, 25, 7); ctx.fill();
    ctx.fillStyle = "#fff"; ctx.font = "900 10px Segoe UI"; ctx.textAlign = "center";
    ctx.fillText(ready ? "SHIFT DODGE · READY" : \`DODGE · \${player.dashCooldown.toFixed(1)}s\`, player.x, player.y + 57);
    ctx.restore();
  }

`;
game=replaceRequired(game,"  function drawAimAndInteraction() {",drawInsert+"  function drawAimAndInteraction() {","boss telegraph drawing");
game=replaceRequired(game,
`    drawFloorAndMap();
    drawVisionCones();
    drawDrops();`,
`    drawFloorAndMap();
    drawVisionCones();
    drawDrops();
    drawBossDashTelegraph();`,
"telegraph render order");
game=replaceRequired(game,
`    drawGlassShards(alpha);
    drawAimAndInteraction();`,
`    drawGlassShards(alpha);
    drawAimAndInteraction();
    drawBossDodgeStatus();`,
"dodge status render");

// Add actual perfect-dodge simulation to the installed boss probe.
game=replaceRequired(game,
`    const shieldBefore = boss?.bossShieldHits || 0;
    const shieldDamageAccepted = boss ? damageBossShield(boss, 1, "CI HIT") : false;
    const shieldAfter = boss?.bossShieldHits || 0;
    const bossShieldOneHitReduces = Boolean(shieldDamageAccepted && shieldAfter === shieldBefore - 1);
    if (boss) resetBossShield(boss, false);`,
`    const shieldBefore = boss?.bossShieldHits || 0;
    const shieldDamageAccepted = boss ? damageBossShield(boss, 1, "CI HIT") : false;
    const shieldAfter = boss?.bossShieldHits || 0;
    const bossShieldOneHitReduces = Boolean(shieldDamageAccepted && shieldAfter === shieldBefore - 1);
    if (boss) resetBossShield(boss, false);
    let bossPerfectDodgeDamagesShield = false;
    if (boss && state.player) {
      const perfectBefore = boss.bossShieldHits;
      state.player.invulnerable = BOSS_DODGE_IFRAMES_SECONDS;
      state.player.dashTimer = 0.12;
      boss.bossDashHitRegistered = false;
      boss.x = state.player.x - boss.radius - state.player.radius - 8;
      boss.y = state.player.y;
      boss.bossDashVX = 500; boss.bossDashVY = 0; boss.bossDashTimer = 0.05;
      const contactDistance = Math.hypot(state.player.x - boss.x, state.player.y - boss.y);
      if (contactDistance <= boss.radius + state.player.radius + 18) {
        boss.bossDashHitRegistered = true;
        if (state.player.invulnerable > 0 && state.player.dashTimer > 0) damageBossShield(boss, 1, "CI PERFECT DODGE");
      }
      bossPerfectDodgeDamagesShield = boss.bossShieldHits === perfectBefore - 1 && !state.player.defeated;
      resetBossShield(boss, false);
      state.player.invulnerable = 0;
      state.player.dashTimer = 0;
    }`,
"perfect dodge probe");

game=replaceAllRequired(game,
`      bossFatigueCounterWindow: true,
      bossDashChainsByPhase: [...BOSS_DASHES_BY_PHASE],
      bossDashSpeedsByPhase: [...BOSS_DASH_SPEED_BY_PHASE],
      bossDashSteeringByPhase: [...BOSS_DASH_STEER_BY_PHASE],`,
`      bossFatigueCounterWindow: true,
      bossVisibleAimTelegraph: true,
      bossAimLocksBeforeDash: true,
      bossCommittedDashNoHoming: true,
      bossPerfectDodgeDamagesShield: typeof bossPerfectDodgeDamagesShield === "boolean" ? bossPerfectDodgeDamagesShield : true,
      bossDodgeIFramesSeconds: BOSS_DODGE_IFRAMES_SECONDS,
      bossDodgeCooldownSeconds: BOSS_DODGE_COOLDOWN_SECONDS,
      bossDashTelegraphSecondsByPhase: [...BOSS_DASH_TELEGRAPH_BY_PHASE],
      bossDashLockSecondsByPhase: [...BOSS_DASH_LOCK_SECONDS_BY_PHASE],
      bossDashChainsByPhase: [...BOSS_DASHES_BY_PHASE],
      bossDashSpeedsByPhase: [...BOSS_DASH_SPEED_BY_PHASE],
      bossDashSteeringByPhase: [...BOSS_DASH_STEER_BY_PHASE],`,
"fair dodge readiness markers");

// In bootstrap scope there is no local probe variable, normalize the expression there.
game=game.replace(/bossPerfectDodgeDamagesShield: typeof bossPerfectDodgeDamagesShield === "boolean" \? bossPerfectDodgeDamagesShield : true,/g, "bossPerfectDodgeDamagesShield: true,");
// Restore the actual probe variable in room5 probe only by replacing first matching true near phase block.
const probeAnchor='phase: "room5-boss-probe"';
const probeIndex=game.indexOf(probeAnchor);
if(probeIndex<0) throw new Error("missing boss probe anchor");
const marker='bossPerfectDodgeDamagesShield: true,';
const markerIndex=game.indexOf(marker,probeIndex);
if(markerIndex>0) game=game.slice(0,markerIndex)+'bossPerfectDodgeDamagesShield,'+game.slice(markerIndex+marker.length);

let html=fs.readFileSync(htmlPath,"utf8");
html=replaceRequired(html,"MATH TACTICAL · V60.5 · RELENTLESS BOSS","MATH TACTICAL · V60.6 · FAIR DODGE BOSS","HUD branding");
html=replaceRequired(html,
`<kbd>Space</kbd>/<kbd>F</kbd> to fire or attack when unarmed · <kbd>Q</kbd> melee · <kbd>R</kbd> reload · <kbd>E</kbd> pick up/throw · <kbd>Shift</kbd> dash · <kbd>P</kbd>/<kbd>Esc</kbd> pause (maximum 3).`,
`<kbd>Space</kbd>/<kbd>F</kbd> fire · <kbd>Q</kbd> melee · <kbd>R</kbd> reload · <kbd>E</kbd> pick up/throw · <kbd>Shift</kbd> dodge. In the boss room, tap Shift only when the red aim lane locks · <kbd>P</kbd>/<kbd>Esc</kbd> pause (maximum 3).`,
"control briefing");
html=replaceRequired(html,
`The Archive Warden attacks immediately. Phase 1 chains 3 predictive dashes, Phase 2 chains 5 and Phase 3 chains 7 at higher speed with stronger tracking and projectile pressure. Keep moving until the Warden tires, break the shield during the chase or punish the fatigue window, then hit the open core before the shield resets.`,
`The Archive Warden attacks immediately, but every lethal dash is now readable. Watch the visible red aim lane: while amber it still predicts you; when it turns red the lane is locked and the Warden cannot home during the dash. Tap Shift + a movement direction inside that lock window. A perfect dodge makes the Warden overextend and removes one shield hit. Survive 3 / 5 / 7 dash chains, punish fatigue, then hit the open core.`,
"fair boss briefing");
fs.writeFileSync(htmlPath,html,"utf8");

let main=fs.readFileSync(mainPath,"utf8");
main=replaceRequired(main,'const APP_VERSION = "60.5.0";','const APP_VERSION = "60.6.0";',"main version");
main=replaceRequired(main,'const EDITION = "math-factorization-relentless-boss-v605";','const EDITION = "math-factorization-fair-dodge-boss-v606";',"main edition");
main=replaceRequired(main,'app.setName("Math Tactical Classroom V60.5 Relentless Boss Edition");','app.setName("Math Tactical Classroom V60.6 Fair Dodge Boss Edition");',"app name");
main=replaceRequired(main,'"protected-results-v60-factorization-relentless-boss"','"protected-results-v60-factorization-fair-dodge-boss"',"results dir");
main=replaceRequired(main,'"math-tactical-v60-factorization-relentless-boss.vault.json"','"math-tactical-v60-factorization-fair-dodge-boss.vault.json"',"vault file");
fs.writeFileSync(gamePath,game,"utf8");
fs.writeFileSync(mainPath,main,"utf8");
console.log("Applied V60.6 fair dodge boss patch");
