"use strict";
const fs = require("node:fs");
const path = require("node:path");
const root = path.join(__dirname, "..");
const gamePath = path.join(root, "school-game", "v60", "game.js");
const htmlPath = path.join(root, "school-game", "v60", "index.html");
const mainPath = path.join(root, "school-game", "v60", "main.js");
function rep(src, before, after, label) {
  if (!src.includes(before)) throw new Error(`V60.7 mastery patch could not find ${label}.`);
  return src.replace(before, after);
}
function repAll(src, before, after, label) {
  if (!src.includes(before)) throw new Error(`V60.7 mastery patch could not find ${label}.`);
  return src.split(before).join(after);
}
let game = fs.readFileSync(gamePath, "utf8");
game = rep(game, 'const VERSION = "60.6.0";', 'const VERSION = "60.7.0";', "renderer version");
game = rep(game, 'const EDITION = "math-factorization-fair-dodge-boss-v606";', 'const EDITION = "math-factorization-mastery-boss-v607";', "renderer edition");
game = rep(game, 'const BOSS_VULNERABLE_SECONDS = 5.5;', 'const BOSS_VULNERABLE_SECONDS = 4.4;', "boss vulnerable window");
game = rep(game,
`  const BOSS_SHIELD_HITS_BY_PHASE = Object.freeze([4, 5, 6]);
  const BOSS_DASHES_BY_PHASE = Object.freeze([3, 5, 7]);
  const BOSS_DASH_SPEED_BY_PHASE = Object.freeze([740, 900, 1040]);
  const BOSS_DASH_TELEGRAPH_BY_PHASE = Object.freeze([0.76, 0.62, 0.50]);
  const BOSS_DASH_LOCK_SECONDS_BY_PHASE = Object.freeze([0.24, 0.20, 0.17]);
  const BOSS_DASH_DURATION_BY_PHASE = Object.freeze([0.25, 0.27, 0.29]);
  const BOSS_DASH_CHAIN_GAP_BY_PHASE = Object.freeze([0.34, 0.30, 0.27]);
  const BOSS_FATIGUE_SECONDS_BY_PHASE = Object.freeze([2.80, 2.35, 1.90]);
  const BOSS_PREDICTION_SECONDS_BY_PHASE = Object.freeze([0.22, 0.36, 0.50]);
  const BOSS_DASH_STEER_BY_PHASE = Object.freeze([0, 0, 0]);
  const BOSS_DODGE_IFRAMES_SECONDS = 0.30;
  const BOSS_DODGE_COOLDOWN_SECONDS = 0.42;
  const BOSS_ROOM_PICKUP_RADIUS = 118;`,
`  const BOSS_SHIELD_HITS_BY_PHASE = Object.freeze([6, 8, 10]);
  const BOSS_CORE_HITS_BY_PHASE = Object.freeze([3, 4, 5]);
  const BOSS_DASHES_BY_PHASE = Object.freeze([4, 6, 8]);
  const BOSS_DASH_SPEED_BY_PHASE = Object.freeze([820, 990, 1160]);
  const BOSS_DASH_TELEGRAPH_BY_PHASE = Object.freeze([0.58, 0.48, 0.40]);
  const BOSS_DASH_LOCK_SECONDS_BY_PHASE = Object.freeze([0.24, 0.20, 0.17]);
  const BOSS_DASH_DURATION_BY_PHASE = Object.freeze([0.27, 0.29, 0.31]);
  const BOSS_DASH_CHAIN_GAP_BY_PHASE = Object.freeze([0.22, 0.18, 0.15]);
  const BOSS_FATIGUE_SECONDS_BY_PHASE = Object.freeze([1.55, 1.20, 0.90]);
  const BOSS_PREDICTION_SECONDS_BY_PHASE = Object.freeze([0.24, 0.40, 0.56]);
  const BOSS_DASH_STEER_BY_PHASE = Object.freeze([0, 0, 0]);
  const BOSS_DODGE_IFRAMES_SECONDS = 0.18;
  const BOSS_DODGE_COOLDOWN_SECONDS = 0.38;
  const BOSS_DODGE_FINAL_CUE_SECONDS = 0.12;
  const BOSS_CORE_HIT_COOLDOWN_SECONDS = 0.16;
  const BOSS_MASTERY_TARGET_DEATHS = 30;
  const BOSS_MASTERY_ASSIST_TELEGRAPH = 0.07;
  const BOSS_MASTERY_ASSIST_IFRAMES = 0.02;
  const BOSS_MASTERY_ASSIST_FATIGUE = 0.22;
  const BOSS_ROOM_PICKUP_RADIUS = 118;`, "mastery boss constants");

game = rep(game,
`  function enterBossFatigue(enemy, reason = "DASH CHAIN EXHAUSTED") {
    if (!enemy || enemy.defeated) return;
    const phaseIndex = bossPhaseIndex(enemy);
    enemy.bossRushActive = false;
    enemy.bossDashTimer = 0;
    enemy.bossDashTelegraph = 0;
    enemy.bossDashTelegraphMax = 0;
    enemy.bossDashAimLocked = false;
    enemy.bossDashVX = 0;
    enemy.bossDashVY = 0;
    enemy.bossFatigueTimer = BOSS_FATIGUE_SECONDS_BY_PHASE[phaseIndex];
    enemy.vx = 0; enemy.vy = 0;
    enemy.action = "idle";
    banner(\`WARDEN TIRED · \${reason} · COUNTER \${enemy.bossFatigueTimer.toFixed(1)} s\`, 1500);
    tone(210, 0.12, 0.028, "triangle");
  }`,
`  function enterBossFatigue(enemy, reason = "DASH CHAIN EXHAUSTED") {
    if (!enemy || enemy.defeated) return;
    const phaseIndex = bossPhaseIndex(enemy);
    const masteryBonus = Math.min(0.36, (enemy.bossPerfectDodgeStreak || 0) * 0.06);
    const deathAssist = (state.bossDeaths || 0) >= BOSS_MASTERY_TARGET_DEATHS ? BOSS_MASTERY_ASSIST_FATIGUE : 0;
    enemy.bossRushActive = false;
    enemy.bossDashTimer = 0;
    enemy.bossDashTelegraph = 0;
    enemy.bossDashTelegraphMax = 0;
    enemy.bossDashAimLocked = false;
    enemy.bossDashFinalCuePlayed = false;
    enemy.bossDashVX = 0;
    enemy.bossDashVY = 0;
    enemy.bossFatigueTimer = BOSS_FATIGUE_SECONDS_BY_PHASE[phaseIndex] + masteryBonus + deathAssist;
    enemy.bossPerfectDodgeStreak = 0;
    enemy.vx = 0; enemy.vy = 0;
    enemy.action = "idle";
    banner(\`WARDEN RECOVERY · \${reason} · PUNISH \${enemy.bossFatigueTimer.toFixed(1)} s\`, 1300);
    tone(210, 0.12, 0.028, "triangle");
  }`, "fatigue mastery reward");

game = rep(game,
`    enemy.bossShieldActive = true;
    enemy.bossVulnerableUntil = 0;
    if (announce) banner(\`WARDEN SHIELD RESTORED · \${hits} hits\`, 1600);`,
`    enemy.bossShieldActive = true;
    enemy.bossVulnerableUntil = 0;
    enemy.bossCoreHitCooldown = 0;
    enemy.bossCoreHitsRemaining = BOSS_CORE_HITS_BY_PHASE[bossPhaseIndex(enemy)];
    if (announce) banner(\`WARDEN SHIELD RESTORED · \${hits} hits\`, 1600);`, "core armor reset");

game = rep(game,
`      enemy.bossVulnerableUntil = performance.now() / 1000 + BOSS_VULNERABLE_SECONDS;
      enemy.bossHintCooldown = 0;`,
`      enemy.bossVulnerableUntil = performance.now() / 1000 + BOSS_VULNERABLE_SECONDS;
      enemy.bossCoreHitsRemaining = BOSS_CORE_HITS_BY_PHASE[bossPhaseIndex(enemy)];
      enemy.bossCoreHitCooldown = 0;
      enemy.bossHintCooldown = 0;`, "core armor on shield break");

game = rep(game,
`  function damageBossCore(enemy, sourceLabel = "CORE HIT") {
    if (!enemy || enemy.defeated || enemy.bossShieldActive) return false;
    enemy.health = Math.max(0, enemy.health - 1);
    state.hits++;
    state.bossCoreHits++;
    state.screenShake = Math.max(state.screenShake, 14);
    for (let i = 0; i < 28; i++) createParticle(enemy.x, enemy.y, "pixel", "#d89000");
    if (enemy.health <= 0) {`,
`  function damageBossCore(enemy, sourceLabel = "CORE HIT") {
    if (!enemy || enemy.defeated || enemy.bossShieldActive || (enemy.bossCoreHitCooldown || 0) > 0) return false;
    const phaseIndex = bossPhaseIndex(enemy);
    if (!Number.isFinite(enemy.bossCoreHitsRemaining) || enemy.bossCoreHitsRemaining <= 0) enemy.bossCoreHitsRemaining = BOSS_CORE_HITS_BY_PHASE[phaseIndex];
    enemy.bossCoreHitsRemaining = Math.max(0, enemy.bossCoreHitsRemaining - 1);
    enemy.bossCoreHitCooldown = BOSS_CORE_HIT_COOLDOWN_SECONDS;
    state.hits++;
    state.bossCoreHits++;
    state.screenShake = Math.max(state.screenShake, 10);
    for (let i = 0; i < 18; i++) createParticle(enemy.x, enemy.y, "pixel", "#d89000");
    if (enemy.bossCoreHitsRemaining > 0) {
      banner(\`CORE ARMOR · \${enemy.bossCoreHitsRemaining}/\${BOSS_CORE_HITS_BY_PHASE[phaseIndex]} HITS REMAIN · STAY ON TARGET\`, 620);
      tone(520, 0.05, 0.02, "square");
      return true;
    }
    enemy.health = Math.max(0, enemy.health - 1);
    state.screenShake = Math.max(state.screenShake, 14);
    for (let i = 0; i < 18; i++) createParticle(enemy.x, enemy.y, "pixel", "#f0b429");
    if (enemy.health <= 0) {`, "multi-hit core armor");

game = rep(game,
`  function observeBossTarget(enemy, player, dt) {`,
`  function registerBossPerfectDodge(enemy) {
    if (!enemy || enemy.defeated) return false;
    enemy.bossPerfectDodges = (enemy.bossPerfectDodges || 0) + 1;
    enemy.bossPerfectDodgeStreak = (enemy.bossPerfectDodgeStreak || 0) + 1;
    state.bossPerfectDodges = (state.bossPerfectDodges || 0) + 1;
    banner(\`PERFECT DODGE · COUNTER WINDOW +\${Math.min(0.36, enemy.bossPerfectDodgeStreak * 0.06).toFixed(2)} s\`, 650);
    tone(920, 0.07, 0.024, "triangle");
    return true;
  }

  function observeBossTarget(enemy, player, dt) {`, "perfect dodge helper");

game = rep(game,
`  function beginBossDash(enemy, player, opening = false) {
    const phaseIndex = bossPhaseIndex(enemy);
    const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.10);
    enemy.bossDashTargetX = predicted.x;
    enemy.bossDashTargetY = predicted.y;
    const baseTelegraph = BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex];
    enemy.bossDashTelegraph = opening ? Math.max(1.05, baseTelegraph) : baseTelegraph;
    enemy.bossDashTelegraphMax = enemy.bossDashTelegraph;
    enemy.bossDashAimLocked = false;
    enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
    enemy.bossDashHitRegistered = false;
    enemy.bossRushActive = true;
    enemy.bossDashChainRemaining = Math.max(0, (enemy.bossDashChainRemaining || bossDashCountForPhase(enemy)) - 1);
    enemy.action = "charge";
    enemy.actionTimer = enemy.bossDashTelegraph;
    banner(\`WARDEN AIM \${enemy.bossDashChainTotal - enemy.bossDashChainRemaining}/\${enemy.bossDashChainTotal} · WATCH THE RED LANE · TAP SHIFT ON LOCK\`, opening ? 1300 : 780);
    for (let i = 0; i < 14; i++) createParticle(enemy.x, enemy.y, "spark", "#d89000");
    tone(210 - phaseIndex * 18, 0.07, 0.028, "triangle");
  }`,
`  function beginBossDash(enemy, player, opening = false) {
    const phaseIndex = bossPhaseIndex(enemy);
    const predicted = bossPredictedPoint(enemy, player, 1.0 + phaseIndex * 0.10);
    enemy.bossDashTargetX = predicted.x;
    enemy.bossDashTargetY = predicted.y;
    const cadenceIndex = (enemy.bossPatternIndex || 0) % 4;
    enemy.bossPatternIndex = (enemy.bossPatternIndex || 0) + 1;
    const telegraphBias = [0, 0.14, -0.05, 0.05][cadenceIndex];
    const lockBias = [0, 0.08, -0.025, 0.035][cadenceIndex];
    const assist = (state.bossDeaths || 0) >= BOSS_MASTERY_TARGET_DEATHS ? BOSS_MASTERY_ASSIST_TELEGRAPH : 0;
    const baseTelegraph = BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex] + assist;
    enemy.bossDashTelegraph = opening ? Math.max(0.92, baseTelegraph + telegraphBias) : Math.max(0.34, baseTelegraph + telegraphBias);
    enemy.bossDashTelegraphMax = enemy.bossDashTelegraph;
    enemy.bossDashLockDuration = clamp(BOSS_DASH_LOCK_SECONDS_BY_PHASE[phaseIndex] + lockBias + assist * 0.35, 0.125, 0.34);
    enemy.bossDashCadence = ["STANDARD", "HOLD", "QUICK", "LATE"][cadenceIndex];
    enemy.bossDashAimLocked = false;
    enemy.bossDashFinalCuePlayed = false;
    enemy.bossDashCooldown = BOSS_DASH_CHAIN_GAP_BY_PHASE[phaseIndex];
    enemy.bossDashHitRegistered = false;
    enemy.bossRushActive = true;
    enemy.bossDashChainRemaining = Math.max(0, (enemy.bossDashChainRemaining || bossDashCountForPhase(enemy)) - 1);
    enemy.action = "charge";
    enemy.actionTimer = enemy.bossDashTelegraph;
    banner(\`WARDEN \${enemy.bossDashCadence} \${enemy.bossDashChainTotal - enemy.bossDashChainRemaining}/\${enemy.bossDashChainTotal} · READ THE RETICLE\`, opening ? 1200 : 620);
    for (let i = 0; i < 14; i++) createParticle(enemy.x, enemy.y, "spark", "#d89000");
    tone(210 - phaseIndex * 18, 0.07, 0.028, "triangle");
  }`, "variable dash cadence");

game = rep(game,
`    enemy.bossDashCooldown = Math.max(0, enemy.bossDashCooldown - dt);
    updateEnemyWeaponTimers(enemy, dt);`,
`    enemy.bossDashCooldown = Math.max(0, enemy.bossDashCooldown - dt);
    enemy.bossCoreHitCooldown = Math.max(0, (enemy.bossCoreHitCooldown || 0) - dt);
    updateEnemyWeaponTimers(enemy, dt);`, "core hit cooldown update");

game = rep(game,
`        if (player.invulnerable > 0 && player.dashTimer > 0) {
          enemy.bossPerfectDodges = (enemy.bossPerfectDodges || 0) + 1;
          state.bossPerfectDodges = (state.bossPerfectDodges || 0) + 1;
          const shieldWasActive = enemy.bossShieldActive;
          if (shieldWasActive) damageBossShield(enemy, 1, "PERFECT DODGE");
          banner(shieldWasActive ? \`PERFECT DODGE · WARDEN OVEREXTENDS · SHIELD \${enemy.bossShieldHits}/\${enemy.bossShieldMaxHits}\` : "PERFECT DODGE · CORE WINDOW", 850);
          tone(920, 0.08, 0.026, "triangle");
        } else {`,
`        if (player.invulnerable > 0 && player.dashTimer > 0) {
          registerBossPerfectDodge(enemy);
        } else {`, "perfect dodge no free shield damage");

game = rep(game, `Math.hypot(player.x - enemy.x, player.y - enemy.y) <= enemy.radius + player.radius + 18`, `Math.hypot(player.x - enemy.x, player.y - enemy.y) <= enemy.radius + player.radius + 38`, "dash requires dodge radius");

game = rep(game,
`      const lockSeconds = BOSS_DASH_LOCK_SECONDS_BY_PHASE[phaseIndex];
      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph > lockSeconds) {`,
`      const lockSeconds = enemy.bossDashLockDuration || BOSS_DASH_LOCK_SECONDS_BY_PHASE[phaseIndex];
      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph > lockSeconds) {`, "variable lock duration");
game = rep(game,
`      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph <= lockSeconds) {
        enemy.bossDashAimLocked = true;
        banner("DODGE NOW · AIM LOCKED · TAP SHIFT + MOVE", Math.ceil(lockSeconds * 1000));
        tone(1040, 0.055, 0.032, "square");
      }
      enemy.facing = Math.atan2(enemy.bossDashTargetY - enemy.y, enemy.bossDashTargetX - enemy.x);`,
`      if (!enemy.bossDashAimLocked && enemy.bossDashTelegraph <= lockSeconds) {
        enemy.bossDashAimLocked = true;
        banner(\`AIM LOCKED · \${enemy.bossDashCadence || "COMMIT"} · DO NOT PANIC DODGE\`, Math.ceil(lockSeconds * 1000));
        tone(780, 0.05, 0.028, "square");
      }
      if (enemy.bossDashAimLocked && !enemy.bossDashFinalCuePlayed && enemy.bossDashTelegraph <= BOSS_DODGE_FINAL_CUE_SECONDS) {
        enemy.bossDashFinalCuePlayed = true;
        banner("DODGE!", 150);
        tone(1220, 0.045, 0.036, "square");
      }
      enemy.facing = Math.atan2(enemy.bossDashTargetY - enemy.y, enemy.bossDashTargetX - enemy.x);`, "final dodge cue");

game = rep(game,
`      player.dashCooldown = bossRoomDodge ? BOSS_DODGE_COOLDOWN_SECONDS : 1.25;
      player.dashTimer = bossRoomDodge ? 0.22 : 0.16;
      player.invulnerable = Math.max(player.invulnerable, bossRoomDodge ? BOSS_DODGE_IFRAMES_SECONDS : 0.18);
      player.action = "dash";
      player.actionTimer = bossRoomDodge ? 0.24 : 0.2;`,
`      player.dashCooldown = bossRoomDodge ? BOSS_DODGE_COOLDOWN_SECONDS : 1.25;
      player.dashTimer = bossRoomDodge ? 0.19 : 0.16;
      const masteryIFrames = BOSS_DODGE_IFRAMES_SECONDS + (((state.bossDeaths || 0) >= BOSS_MASTERY_TARGET_DEATHS) ? BOSS_MASTERY_ASSIST_IFRAMES : 0);
      player.invulnerable = Math.max(player.invulnerable, bossRoomDodge ? masteryIFrames : 0.18);
      player.action = "dash";
      player.actionTimer = bossRoomDodge ? 0.21 : 0.2;`, "narrow mastery dodge");

game = rep(game,
`    state.bossCoreHits = 0;
    state.bossHintsShown = 0;`,
`    state.bossCoreHits = 0;
    state.bossHintsShown = 0;
    state.bossDeaths = 0;`, "boss death counter reset");

game = rep(game,
`    player.defeated = true;
    player.defeatTimer = 0;`,
`    player.defeated = true;
    player.defeatTimer = 0;
    if (MAPS[state.levelIndex]?.bossRoom) {
      state.bossDeaths = (state.bossDeaths || 0) + 1;
      if (state.bossDeaths === BOSS_MASTERY_TARGET_DEATHS) banner("30 BOSS DEATHS · MASTERY ASSIST ACTIVE · SLIGHTLY LONGER TELLS", 2200);
    }`, "boss death mastery counter");

game = rep(game,
`    const locked = Boolean(boss.bossDashAimLocked);
    const total = Math.max(0.001, boss.bossDashTelegraphMax || BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex]);`,
`    const locked = Boolean(boss.bossDashAimLocked);
    const finalCue = locked && boss.bossDashTelegraph <= BOSS_DODGE_FINAL_CUE_SECONDS;
    const total = Math.max(0.001, boss.bossDashTelegraphMax || BOSS_DASH_TELEGRAPH_BY_PHASE[phaseIndex]);`, "telegraph final cue state");
game = repAll(game,
`ctx.strokeStyle = locked ? "rgba(196,61,61,.28)" : "rgba(216,144,0,.18)";`,
`ctx.strokeStyle = finalCue ? "rgba(255,255,255,.34)" : locked ? "rgba(196,61,61,.28)" : "rgba(216,144,0,.18)";`, "telegraph lane fill");
game = rep(game,
`    ctx.strokeStyle = locked ? "#c43d3d" : "#d89000";
    ctx.lineWidth = locked ? 5 : 3;`,
`    ctx.strokeStyle = finalCue ? "#ffffff" : locked ? "#c43d3d" : "#d89000";
    ctx.lineWidth = finalCue ? 7 : locked ? 5 : 3;`, "telegraph line cue");
game = rep(game,
`    ctx.fillStyle = locked ? "rgba(196,61,61,.14)" : "rgba(216,144,0,.10)";`,
`    ctx.fillStyle = finalCue ? "rgba(255,255,255,.18)" : locked ? "rgba(196,61,61,.14)" : "rgba(216,144,0,.10)";`, "telegraph target fill");
game = rep(game,
`    ctx.strokeStyle = locked ? "#c43d3d" : "#d89000";`,
`    ctx.strokeStyle = finalCue ? "#ffffff" : locked ? "#c43d3d" : "#d89000";`, "telegraph target color");
game = rep(game,
`    ctx.fillStyle = locked ? "#fff" : "#f8d57e";
    ctx.font = "900 12px Segoe UI"; ctx.textAlign = "center";
    ctx.fillText(locked ? "DODGE NOW · TAP SHIFT" : "WARDEN AIMING · WAIT", player.x, player.y - 64);`,
`    ctx.fillStyle = finalCue ? "#ffffff" : locked ? "#ffd9d9" : "#f8d57e";
    ctx.font = "900 12px Segoe UI"; ctx.textAlign = "center";
    ctx.fillText(finalCue ? "DODGE!" : locked ? \`LOCKED · \${boss.bossDashCadence || "COMMIT"} · WATCH RING\` : "WARDEN TRACKING", player.x, player.y - 64);`, "telegraph label");

game = rep(game,
`    let bossPerfectDodgeDamagesShield = false;
    if (boss && state.player) {
      const perfectBefore = boss.bossShieldHits;
      state.player.invulnerable = BOSS_DODGE_IFRAMES_SECONDS;
      state.player.dashTimer = 0.12;
      boss.bossDashHitRegistered = false;
      boss.x = state.player.x - boss.radius - state.player.radius - 8;
      boss.y = state.player.y;
      boss.bossDashVX = 500; boss.bossDashVY = 0; boss.bossDashTimer = 0.05;
      const contactDistance = Math.hypot(state.player.x - boss.x, state.player.y - boss.y);
      if (contactDistance <= boss.radius + state.player.radius + 18) {
        boss.bossDashHitRegistered = true;
        if (state.player.invulnerable > 0 && state.player.dashTimer > 0) damageBossShield(boss, 1, "CI PERFECT DODGE");
      }
      bossPerfectDodgeDamagesShield = boss.bossShieldHits === perfectBefore - 1 && !state.player.defeated;
      resetBossShield(boss, false);
      state.player.invulnerable = 0;
      state.player.dashTimer = 0;
    }`,
`    let bossPerfectDodgeBuildsCounterFocus = false;
    let bossCoreOneHitDoesNotAdvancePhase = false;
    if (boss && state.player) {
      const perfectBefore = boss.bossShieldHits;
      const streakBefore = boss.bossPerfectDodgeStreak || 0;
      registerBossPerfectDodge(boss);
      bossPerfectDodgeBuildsCounterFocus = boss.bossShieldHits === perfectBefore && (boss.bossPerfectDodgeStreak || 0) === streakBefore + 1;
      resetBossShield(boss, false);
      boss.bossShieldActive = false;
      boss.bossVulnerableUntil = performance.now() / 1000 + BOSS_VULNERABLE_SECONDS;
      boss.bossCoreHitsRemaining = BOSS_CORE_HITS_BY_PHASE[0];
      boss.bossCoreHitCooldown = 0;
      const healthBefore = boss.health;
      damageBossCore(boss, "CI CORE");
      bossCoreOneHitDoesNotAdvancePhase = boss.health === healthBefore && boss.bossCoreHitsRemaining === BOSS_CORE_HITS_BY_PHASE[0] - 1;
      resetBossShield(boss, false);
      state.player.invulnerable = 0;
      state.player.dashTimer = 0;
    }`, "CI mastery mechanics");

game = rep(game, `      bossPerfectDodgeDamagesShield,`, `      bossPerfectDodgeDamagesShield: false,
      bossPerfectDodgeBuildsCounterFocus,
      bossCoreOneHitDoesNotAdvancePhase,
      bossCoreHitsRequiredByPhase: [...BOSS_CORE_HITS_BY_PHASE],
      bossMasteryTargetDeaths: BOSS_MASTERY_TARGET_DEATHS,
      bossMasteryAssistAfterDeaths: true,
      bossVariableDashCadence: true,
      bossFinalDodgeCueSeconds: BOSS_DODGE_FINAL_CUE_SECONDS,`, "boss probe mastery markers");
game = rep(game, `      bossPerfectDodgeDamagesShield: true,`, `      bossPerfectDodgeDamagesShield: false,
      bossPerfectDodgeBuildsCounterFocus: true,
      bossCoreMultiHitArmor: true,
      bossCoreHitsRequiredByPhase: [...BOSS_CORE_HITS_BY_PHASE],
      bossMasteryTargetDeaths: BOSS_MASTERY_TARGET_DEATHS,
      bossMasteryAssistAfterDeaths: true,
      bossVariableDashCadence: true,
      bossFinalDodgeCueSeconds: BOSS_DODGE_FINAL_CUE_SECONDS,`, "bootstrap mastery markers");
game = repAll(game, `bossDynamicPatternCount: 6`, `bossDynamicPatternCount: 8`, "boss pattern count");

fs.writeFileSync(gamePath, game, "utf8");
let html = fs.readFileSync(htmlPath, "utf8");
html = rep(html, "MATH TACTICAL · V60.6 · FAIR DODGE BOSS", "MATH TACTICAL · V60.7 · MASTERY BOSS", "HUD branding");
html = rep(html,
`The Archive Warden attacks immediately, but every lethal dash is now readable. Watch the visible red aim lane: while amber it still predicts you; when it turns red the lane is locked and the Warden cannot home during the dash. Tap Shift + a movement direction inside that lock window. A perfect dodge makes the Warden overextend and removes one shield hit. Survive 3 / 5 / 7 dash chains, punish fatigue, then hit the open core.`,
`The Archive Warden is a mastery fight, not a free perfect-dodge loop. Amber tracks you; red means the aim is committed; the shrinking reticle controls the release and flashes white at the final dodge cue. Shift has a narrow i-frame window, so panic-dodging on the first red frame is punishable. Perfect dodges build a longer recovery punish but do not damage the shield for free. Survive 4 / 6 / 8 variable-cadence dash chains, attack during recovery, break 6 / 8 / 10 shield points, then land 3 / 4 / 5 controlled core hits before each phase advances.`, "boss briefing");
fs.writeFileSync(htmlPath, html, "utf8");
let main = fs.readFileSync(mainPath, "utf8");
main = rep(main, 'const APP_VERSION = "60.6.0";', 'const APP_VERSION = "60.7.0";', "main version");
main = rep(main, 'const EDITION = "math-factorization-fair-dodge-boss-v606";', 'const EDITION = "math-factorization-mastery-boss-v607";', "main edition");
main = rep(main, 'app.setName("Math Tactical Classroom V60.6 Fair Dodge Boss Edition");', 'app.setName("Math Tactical Classroom V60.7 Mastery Boss Edition");', "app name");
main = rep(main, '"protected-results-v60-factorization-fair-dodge-boss"', '"protected-results-v60-factorization-mastery-boss"', "results directory");
main = rep(main, '"math-tactical-v60-factorization-fair-dodge-boss.vault.json"', '"math-tactical-v60-factorization-mastery-boss.vault.json"', "vault filename");
fs.writeFileSync(mainPath, main, "utf8");
console.log("Applied Math Tactical V60.7 Mastery Boss patch: variable committed dash cadence, narrow intentional dodge timing, no free shield damage on perfect dodge, multi-hit core armor, 4/6/8 escalating chains, 6/8/10 shields, and a bounded assist only after 30 boss deaths.");
