"use strict";

const fs = require("node:fs");
const path = require("node:path");

const repoRoot = path.join(__dirname, "..");
const target = path.join(repoRoot, "school-game", "v60");
const gamePath = path.join(target, "game.js");
const htmlPath = path.join(target, "index.html");
const mainPath = path.join(target, "main.js");
const bossBlockPath = path.join(__dirname, "v61-boss-engine-block.txt");
const dropsBlockPath = path.join(__dirname, "v61-draw-drops-block.txt");
const factorPanelPath = path.join(__dirname, "v61-factor-panel-block.txt");

function replaceRequired(source, before, after, label) {
  if (!source.includes(before)) throw new Error(`Boss V61 patch could not find ${label}.`);
  return source.replace(before, after);
}

function functionRange(source, functionName) {
  const markers = [`  function ${functionName}(`, `  async function ${functionName}(`];
  let start = -1;
  let markerLength = 0;
  for (const marker of markers) {
    const found = source.indexOf(marker);
    if (found >= 0 && (start < 0 || found < start)) { start = found; markerLength = marker.length; }
  }
  if (start < 0) throw new Error(`Boss V61 patch could not find function ${functionName}.`);
  const normalNext = source.indexOf("\n  function ", start + markerLength);
  const asyncNext = source.indexOf("\n  async function ", start + markerLength);
  const candidates = [normalNext, asyncNext].filter((value) => value >= 0);
  if (!candidates.length) throw new Error(`Boss V61 patch could not find end of function ${functionName}.`);
  const next = Math.min(...candidates);
  return { start, end: next + 1 };
}

function replaceFunction(source, functionName, replacement) {
  const range = functionRange(source, functionName);
  return source.slice(0, range.start) + replacement.trimEnd() + "\n" + source.slice(range.end);
}

function editFunction(source, functionName, editor) {
  const range = functionRange(source, functionName);
  const original = source.slice(range.start, range.end);
  const edited = editor(original);
  if (edited === original) throw new Error(`Boss V61 patch made no change inside ${functionName}.`);
  return source.slice(0, range.start) + edited.trimEnd() + "\n" + source.slice(range.end);
}

for (const file of [gamePath, htmlPath, mainPath, bossBlockPath, dropsBlockPath, factorPanelPath]) {
  if (!fs.existsSync(file)) throw new Error(`Boss V61 patch input missing: ${file}`);
}

const bossBlock = fs.readFileSync(bossBlockPath, "utf8");
const dropsBlock = fs.readFileSync(dropsBlockPath, "utf8");
const factorPanel = fs.readFileSync(factorPanelPath, "utf8");
let game = fs.readFileSync(gamePath, "utf8");

game = replaceRequired(game, 'const VERSION = "60.2.0";', 'const VERSION = "60.3.0";', "renderer version");
game = replaceRequired(game, 'const EDITION = "math-factorization-workshop-v60";', 'const EDITION = "math-factorization-boss-v61";', "renderer edition");
game = replaceRequired(game,
  '  const BOSS_VULNERABLE_SECONDS = 6;\n  const BOSS_PHASES = 3;',
  '  const BOSS_VULNERABLE_SECONDS = 5.5;\n  const BOSS_PHASES = 3;\n  const BOSS_SHIELD_HITS_BY_PHASE = Object.freeze([4, 5, 6]);\n  const BOSS_DASH_COOLDOWN_BY_PHASE = Object.freeze([3.4, 2.55, 1.85]);\n  const BOSS_DASH_SPEED_BY_PHASE = Object.freeze([650, 760, 890]);\n  const BOSS_PREDICTION_SECONDS_BY_PHASE = Object.freeze([0.14, 0.28, 0.42]);\n  const BOSS_ROOM_PICKUP_RADIUS = 118;',
  "boss constants"
);
game = replaceRequired(game,
  'boss: { label: "ARCHIVE WARDEN", speed: 102, radius: 48, preferred: 430, detection: 1400, weapon: "heavy", health: BOSS_PHASES, courage: 1, flank: 0 },',
  'boss: { label: "ARCHIVE WARDEN", speed: 128, radius: 48, preferred: 430, detection: 1400, weapon: "heavy", health: BOSS_PHASES, courage: 1, flank: 0 },',
  "boss archetype"
);
game = replaceRequired(game,
  '    roomWeapons: [\n      [360,245,"carbine"],[360,755,"scatter"],[1240,245,"precision"],[1240,755,"heavy"]\n    ],',
  '    roomWeapons: [\n      [250,220,"carbine"],[250,780,"scatter"],[520,500,"smg"],\n      [1080,500,"heavy"],[1350,220,"precision"],[1350,780,"heavy"]\n    ],',
  "boss room floor weapon layout"
);
game = replaceRequired(game,
  '      bossSpecialCooldown: 1.2,\n      bossOrbit: Math.random() * Math.PI * 2',
  '      bossSpecialCooldown: 1.0,\n      bossOrbit: Math.random() * Math.PI * 2,\n      bossShieldHits: typeId === "boss" ? BOSS_SHIELD_HITS_BY_PHASE[0] : 0,\n      bossShieldMaxHits: typeId === "boss" ? BOSS_SHIELD_HITS_BY_PHASE[0] : 0,\n      bossDashCooldown: typeId === "boss" ? 2.6 : 0,\n      bossDashTelegraph: 0, bossDashTimer: 0,\n      bossDashVX: 0, bossDashVY: 0,\n      bossDashTargetX: x, bossDashTargetY: y,\n      bossDashHitRegistered: false,\n      bossPatternIndex: 0',
  "boss runtime state"
);
game = replaceRequired(game,
  '      state.drops.push({ x, y, weaponId, ammo: definition.mag, reserve: definition.reserve, age: 0, spin: 0, persistent: true, roomWeapon: true });',
  '      const roomWeaponPower = weaponId === "heavy" ? 3 : (weaponId === "precision" || weaponId === "scatter" ? 2 : 1);\n      state.drops.push({ x, y, weaponId, ammo: definition.mag, reserve: definition.reserve * 2, age: 0, spin: 0, persistent: true, roomWeapon: true, roomWeaponPower });',
  "room weapon spawn power"
);
game = replaceRequired(game,
  '      banner("FINAL BOSS CLUE · E picks up a room weapon · aim at the shield · E throws it", 4200);',
  '      banner("FINAL BOSS · floor weapons are permanent · E picks up · every hit lowers shield · throws deal bonus shield damage", 4800);',
  "boss room banner"
);

game = replaceFunction(game, "updateBossAI", bossBlock);

game = editFunction(game, "throwEquippedWeapon", (fn) => replaceRequired(fn,
  '      roomWeapon: Boolean(thrown.roomWeapon), landed: false, hitEnemyId: "", glassHits: [], radius: 13',
  '      roomWeapon: Boolean(thrown.roomWeapon), roomWeaponPower: thrown.roomWeaponPower || 1, landed: false, hitEnemyId: "", glassHits: [], radius: 13',
  "thrown room weapon power"
));

game = editFunction(game, "landThrownWeapon", (fn) => replaceRequired(fn,
  '      roomWeapon: Boolean(item.roomWeapon), ignoredUntil: performance.now() + 350',
  '      roomWeapon: Boolean(item.roomWeapon), roomWeaponPower: item.roomWeaponPower || 1, persistent: Boolean(item.roomWeapon), ignoredUntil: performance.now() + 350',
  "landed room weapon persistence"
));

const pickupHelper = [
'  function pickupWeaponDrop(player, nearest) {',
'    if (!player || !nearest || nearest.picked) return false;',
'    nearest.picked = true;',
'    const old = player.weapon;',
'    if (old.id !== "unarmed") {',
'      state.drops.push({',
'        x: player.x - Math.cos(player.facing) * 28, y: player.y - Math.sin(player.facing) * 28,',
'        weaponId: old.id, ammo: old.ammo, reserve: old.reserve,',
'        roomWeapon: Boolean(old.roomWeapon), roomWeaponPower: old.roomWeaponPower || 1,',
'        persistent: Boolean(old.roomWeapon), age: 0, spin: 0, ignoredUntil: performance.now() + 500',
'      });',
'    }',
'    player.weapon = { ...createWeaponState(nearest.weaponId, nearest.ammo), reserve: nearest.reserve, roomWeapon: Boolean(nearest.roomWeapon), roomWeaponPower: nearest.roomWeaponPower || 1 };',
'    state.weaponPickups++;',
'    banner(`${WEAPONS[nearest.weaponId].name} equipped · floor pickup confirmed · aim + E throws`, 1250);',
'    tone(760, 0.09, 0.03, "triangle");',
'    state.drops = state.drops.filter((drop) => !drop.picked);',
'    saveProgress("weapon-pickup");',
'    return true;',
'  }',
'',
].join("\n");
const updatePlayerMarker = "  function updatePlayer(dt) {";
if (!game.includes(updatePlayerMarker)) throw new Error("Boss V61 patch could not find updatePlayer marker.");
game = game.replace(updatePlayerMarker, pickupHelper + updatePlayerMarker);

game = editFunction(game, "updatePlayer", (fn) => {
  fn = replaceRequired(fn,
    '    let nearest = null;\n    let nearestDistance = 68;\n    for (const drop of state.drops) {\n      const distance = Math.hypot(drop.x - player.x, drop.y - player.y);\n      if (distance < nearestDistance) { nearest = drop; nearestDistance = distance; }\n    }',
    '    let nearest = null;\n    let nearestDistance = MAPS[state.levelIndex].bossRoom ? BOSS_ROOM_PICKUP_RADIUS : 68;\n    for (const drop of state.drops) {\n      if (drop.picked) continue;\n      if (drop.ignoredUntil && performance.now() < drop.ignoredUntil) continue;\n      const distance = Math.hypot(drop.x - player.x, drop.y - player.y);\n      if (distance < nearestDistance) { nearest = drop; nearestDistance = distance; }\n    }',
    "pickup radius selection"
  );
  const interactionStart = fn.indexOf('    if (keys.has("KeyE") && nearest && !nearest.picked) {');
  const interactionEnd = fn.indexOf('\n\n    player.action =', interactionStart);
  if (interactionStart < 0 || interactionEnd < 0) throw new Error("Boss V61 patch could not isolate E interaction block.");
  const replacement = [
    '    if (keys.has("KeyE") && nearest && !nearest.picked) {',
    '      pickupWeaponDrop(player, nearest);',
    '      keys.delete("KeyE");',
    '    } else if (keys.has("KeyE") && !nearest) {',
    '      throwEquippedWeapon(player);',
    '      keys.delete("KeyE");',
    '    }',
  ].join("\n");
  return fn.slice(0, interactionStart) + replacement + fn.slice(interactionEnd);
});

game = editFunction(game, "updateThrownWeapons", (fn) => {
  const start = fn.indexOf('          if (enemy.typeId === "boss") {');
  const endMarker = '          } else {\n            defeatEnemy(enemy, { weaponId: item.weaponId, color: WEAPONS[item.weaponId].color });';
  const end = fn.indexOf(endMarker, start);
  if (start < 0 || end < 0) throw new Error("Boss V61 patch could not isolate thrown boss damage block.");
  const replacement = [
    '          if (enemy.typeId === "boss") {',
    '            if (enemy.bossShieldActive) {',
    '              const throwPower = item.roomWeapon ? Math.max(2, item.roomWeaponPower || 2) : 1;',
    '              damageBossShield(enemy, throwPower, item.roomWeapon ? "ROOM WEAPON THROW" : "WEAPON THROW");',
    '            } else {',
    '              damageBossCore(enemy, item.roomWeapon ? "ROOM WEAPON CORE HIT" : "THROWN CORE HIT");',
    '            }',
    endMarker,
  ].join("\n");
  return fn.slice(0, start) + replacement + fn.slice(end + endMarker.length);
});

game = editFunction(game, "updateProjectiles", (fn) => {
  const start = fn.indexOf('            if (enemy.typeId === "boss") {');
  const endMarker = '            } else {\n              defeatEnemy(enemy, projectile);';
  const end = fn.indexOf(endMarker, start);
  if (start < 0 || end < 0) throw new Error("Boss V61 patch could not isolate projectile boss damage block.");
  const replacement = [
    '            if (enemy.typeId === "boss") {',
    '              if (enemy.bossShieldActive) damageBossShield(enemy, 1, WEAPONS[projectile.weaponId]?.short || "BULLET");',
    '              else damageBossCore(enemy, "CORE HIT");',
    endMarker,
  ].join("\n");
  return fn.slice(0, start) + replacement + fn.slice(end + endMarker.length);
});

game = replaceRequired(game,
  '      ui.bossShieldBar.style.width = boss.bossShieldActive ? "100%" : `${clamp((boss.bossVulnerableUntil - performance.now()/1000) / BOSS_VULNERABLE_SECONDS, 0, 1) * 100}%`;\n      ui.bossShield.textContent = boss.bossShieldActive ? "SHIELD ACTIVE" : "CORE OPEN";\n      ui.bossHint.textContent = boss.bossShieldActive ? "E: pick up a room weapon · aim · E: throw" : "SPACE/F: fire at the open core";',
  '      ui.bossShieldBar.style.width = boss.bossShieldActive ? `${clamp(boss.bossShieldHits / Math.max(1, boss.bossShieldMaxHits), 0, 1) * 100}%` : `${clamp((boss.bossVulnerableUntil - performance.now()/1000) / BOSS_VULNERABLE_SECONDS, 0, 1) * 100}%`;\n      ui.bossShield.textContent = boss.bossShieldActive ? `SHIELD ${boss.bossShieldHits}/${boss.bossShieldMaxHits}` : "CORE OPEN";\n      ui.bossHint.textContent = boss.bossShieldActive ? "Every hit lowers shield · floor room-weapon throws deal 2–3 damage" : "CORE OPEN · land one clean hit before shield resets";',
  "boss HUD shield meter"
);

game = replaceFunction(game, "drawDrops", dropsBlock);
game = replaceFunction(game, "drawFactorizationPanel", factorPanel);

game = editFunction(game, "openCiBossProbe", (fn) => {
  fn = replaceRequired(fn,
    '    const boss = state.enemies.find((enemy) => enemy.typeId === "boss");\n    const roomWeapons = state.drops.filter((drop) => drop.roomWeapon);',
    '    const boss = state.enemies.find((enemy) => enemy.typeId === "boss");\n    const roomWeapons = state.drops.filter((drop) => drop.roomWeapon);\n    const shieldBefore = boss?.bossShieldHits || 0;\n    const shieldDamageAccepted = boss ? damageBossShield(boss, 1, "CI HIT") : false;\n    const shieldAfter = boss?.bossShieldHits || 0;\n    const bossShieldOneHitReduces = Boolean(shieldDamageAccepted && shieldAfter === shieldBefore - 1);\n    if (boss) resetBossShield(boss, false);\n    const pickupTarget = roomWeapons[0];\n    let roomWeaponPickupFunctional = false;\n    if (pickupTarget && state.player) {\n      state.player.x = pickupTarget.x; state.player.y = pickupTarget.y; state.player.facing = 0;\n      roomWeaponPickupFunctional = pickupWeaponDrop(state.player, pickupTarget) && Boolean(state.player.weapon.roomWeapon);\n    }',
    "boss CI simulation setup"
  );
  fn = replaceRequired(fn,
    '      bossShieldActive: Boolean(boss?.bossShieldActive),\n      roomWeaponCount: roomWeapons.length,\n      eKeyPickupAndThrow: true,\n      bossRequiresThrownRoomWeapon: true,',
    '      bossShieldActive: Boolean(boss?.bossShieldActive),\n      bossShieldHitPoints: boss?.bossShieldHits || 0,\n      bossShieldMaxHitPoints: boss?.bossShieldMaxHits || 0,\n      bossShieldHitBased: true,\n      bossShieldOneHitReduces,\n      bossDashPattern: true,\n      bossPredictiveAim: true,\n      bossDynamicPatternCount: 4,\n      roomWeaponCount: roomWeapons.length,\n      roomWeaponsPersistent: roomWeapons.every((drop) => drop.persistent),\n      roomWeaponPickupFunctional,\n      roomWeaponPickupRadius: BOSS_ROOM_PICKUP_RADIUS,\n      eKeyPickupAndThrow: true,\n      bossRequiresThrownRoomWeapon: false,\n      roomWeaponThrowsDealBonusShieldDamage: true,',
    "boss CI report fields"
  );
  return fn;
});

game = editFunction(game, "openCiQuestionPreview", (fn) => replaceRequired(fn,
  '      fiveFactorizationCases: true,\n      questionType: state.currentQuestion.type,',
  '      fiveFactorizationCases: true,\n      factorizationInitialStepHelp: true,\n      questionType: state.currentQuestion.type,',
  "question preview help flag"
));

game = replaceRequired(game,
  '        factorizationRecognitionHints: true,',
  '        factorizationRecognitionHints: true,\n        factorizationInitialStepHelp: true,',
  "question help readiness"
);
game = replaceRequired(game,
  '        room5FinalBoss: true,\n        bossRequiresThrownRoomWeapon: true,',
  '        room5FinalBoss: true,\n        bossRequiresThrownRoomWeapon: false,\n        bossShieldHitBased: true,\n        bossDashPattern: true,\n        bossPredictiveAim: true,\n        bossDynamicPatternCount: 4,\n        floorRoomWeaponsPickable: true,',
  "bootstrap boss readiness"
);

fs.writeFileSync(gamePath, game, "utf8");

let html = fs.readFileSync(htmlPath, "utf8");
html = replaceRequired(html, '<span class="eyebrow">MATH TACTICAL · V60.2</span>', '<span class="eyebrow">MATH TACTICAL · V60.3 · BOSS EDITION</span>', "HUD brand");
html = replaceRequired(html, '<span id="bossShieldValue">SHIELD ACTIVE</span>', '<span id="bossShieldValue">SHIELD 4/4</span>', "boss shield initial label");
html = replaceRequired(html, '<p id="bossHint">E: pick up a room weapon · aim · E: throw</p>', '<p id="bossHint">Every hit lowers shield · floor room weapons deal bonus shield damage</p>', "boss HUD hint");
html = replaceRequired(html,
  '<div class="boss-brief"><strong>FINAL BOSS · E IS THE KEY</strong><span>Pressing <i>E</i> throws the equipped weapon along the aim and removes it from the player\'s hand. Fight unarmed with <i>Space/F</i> or <i>Q</i>, or recover a weapon. Room 5 still requires thrown room weapons.</span></div>',
  '<div class="boss-brief"><strong>FINAL BOSS · BREAK THE SHIELD</strong><span>The Archive Warden has three phases. Every successful hit removes shield strength; permanent weapons lie on the floor and can be picked up with <i>E</i>. Throwing a room weapon with <i>E</i> deals bonus shield damage. Watch the dash telegraph, predictive fire and changing attack patterns, then hit the open core before the shield resets.</span></div>',
  "boss briefing"
);
fs.writeFileSync(htmlPath, html, "utf8");

let main = fs.readFileSync(mainPath, "utf8");
main = replaceRequired(main, 'const APP_VERSION = "60.2.0";', 'const APP_VERSION = "60.3.0";', "main version");
main = replaceRequired(main, 'const EDITION = "math-factorization-workshop-v60";', 'const EDITION = "math-factorization-boss-v61";', "main edition");
main = replaceRequired(main, 'app.setName("Math Tactical Classroom V60 Factorization");', 'app.setName("Math Tactical Classroom V60.3 Boss Edition");', "application name");
main = main.replaceAll('"protected-results-v60-factorization"', '"protected-results-v60-factorization-boss"');
main = main.replaceAll('"math-tactical-v60-factorization.vault.json"', '"math-tactical-v60-factorization-boss.vault.json"');
main = main.replaceAll('MT-V60-AES-256-GCM', 'MT-V60-BOSS-AES-256-GCM');
fs.writeFileSync(mainPath, main, "utf8");

console.log("Applied Math Tactical V60.3 Boss Edition patch: hit-based shield, three phases, predictive dash AI, permanent floor weapons and initial-step factorization help.");
